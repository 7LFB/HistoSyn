import os
import cv2
import re
import numpy as np
import random
from skimage.color import rgb2hed
import pandas as pd
from scipy import stats
import glob
import timm
import random
import seaborn as sns
import argparse
import matplotlib.pyplot as plt
from pdb import set_trace as st
import re
import seaborn as sns
# import multiprocessing as mp
import warnings
warnings.filterwarnings("ignore")
import billiard as mp
import numpy as np
from scipy.stats import chi2
from scipy.stats import norm
from utils.tools import *
from utils.util import *
from utils.spatial_statistics import *




FOLDS_MAP={'F0':0,'F1':1,'F2':2,'F3':3,'F4':4}

def split_list(input_list, num_parts):
    length = len(input_list)
    return [input_list[i*length // num_parts: (i+1)*length // num_parts] 
            for i in range(num_parts)]

# given a slide, it contain multiple tiles, process tiles in loop or multiprocess cores
def single_process_multiple_tiles(tiles,labno,postprocess=None):

    slide_results={'tileName':[],'Proportion-nuclei':[],'Proportion-white':[]}

    for jj, tile_path in enumerate(tiles):

        basename = os.path.basename(tile_path)
        rgbI = cv2.imread(tile_path)[:,:,::-1]
        bgrI = cv2.imread(tile_path)
        grayI = cv2.imread(tile_path,0)
        nuclei_path=os.path.join(PRIOR_DIR,'nuclei_segment',labno,basename)
        white_path=os.path.join(PRIOR_DIR,'white_segment',labno,basename)
   
        nuclei_segment = cv2.imread(nuclei_path,1)
        nucleiM = 1-np.all(nuclei_segment== [0, 0, 0], axis=-1)

        # postprocess='nuclei-D0T0H0B0-white-D0T0H0B0'
        # OR postprocess='D0T100H0B0'
        if 'nuclei' in postprocess:
            ss=postprocess.split('-')
            nucleiDigits=[int(x) for x in re.findall(r'\d+',ss[1])]
            whiteDigits=[int(x) for x in re.findall(r'\d+',ss[-1])]
        else:
            whiteDigits=[int(x) for x in re.findall(r'\d+',postprocess)]
            nucleiDigits=[]
            
        whiteM=white_region_extractor(bgrI,dilate=whiteDigits[0],area_thd=whiteDigits[1],convex_hull=whiteDigits[2],clear_border=whiteDigits[3])

        # further process on mask
        # pass
        if len(nucleiDigits):
            nucleiM=refine_binary_mask(nucleiM,dilate=nucleiDigits[0],area_thd=nucleiDigits[1],convex_hull=nucleiDigits[2],clear_border=nucleiDigits[3])
       
        slide_results['tileName'].append(basename)
        slide_results['Proportion-nuclei'].append(np.sum(nucleiM)/(224*224))
        slide_results['Proportion-white'].append(np.sum(whiteM)/(224*224))

    return slide_results

def multiprocess_multiple_tiles(tiles,labno=None,postprocess=None,cores=1):
    slide_results={'tileName':[],'Proportion-nuclei':[],'Proportion-white':[]}
    tiles_lists = split_list(tiles,num_parts=cores)
    pool = mp.Pool(cores)
    args_list = [(tiles_list,labno,postprocess) for tiles_list in tiles_lists]
    results_list = pool.starmap(single_process_multiple_tiles, args_list)
    for ii in range(0,cores):
        for key in slide_results.keys():
            slide_results[key].extend(results_list[ii][key]) 
    return slide_results


# given a slide, it contain multiple tiles, process tiles in loop or multiprocess cores
def generate_prior_and_calculate_proportion(labno,postprocess=None,cores=10):
    
    slide_folder = os.path.join(SLIDE_DIR,labno)
    # slide_results_path=os.path.join(CSV_DIR,'prior-proportion',f'N{args.prior_nuclei}W{args.prior_white}D{args.dilate}T{args.area_thd}H{args.convex_hull}B{args.clear_border}',f'{labno}.xlsx')
    slide_results_path=os.path.join(CSV_DIR,'prior-proportion',f'{postprocess}',f'{labno}.xlsx')
    mkdirs_if_need(slide_results_path)
    

    tiles = glob.glob(os.path.join(slide_folder,'tile*.png'))

    if cores==1:
        slide_results = single_process_multiple_tiles(tiles,labno=labno,postprocess=postprocess)
    else:
        slide_results = multiprocess_multiple_tiles(tiles,labno=labno,postprocess=postprocess,cores=cores)
        
    slide_df = pd.DataFrame(slide_results)
    slide_df.to_excel(slide_results_path, index=False)
    return slide_df


# given a slide list, it contain multiple slides, process slides in loop or multiprocess cores
def singleprocess_calculate_proportion(df1,method,proportion,fold):
    results={'LabNo':[],'Proportion-Steatosis':[],'Proportion-Inflammation':[],'Proportion-Ballooning':[]}
    PATTERNS=['none','NAS-Inflammation','NAS-Ballooning', 'NAS-Steatosis']

    for ii in range(len(df1)):
        nas_steatosis = df1['NAS-Steatosis'][ii]
        nas_inflammation = df1['NAS-Inflammation'][ii]
        nas_ballooning = df1['NAS-Ballooning'][ii]
        ids = df1['LabNo'][ii] 
        # {'tileName':[],'Prediction':[]}
        df2 = pd.read_excel(os.path.join(LOG_DIR,method,f'F{fold}',f'{ids}.xlsx'))
        # {'tileName':[],'Proportion-nuclei':[],'Proportion-white':[]}
        areaProporPath=os.path.join(PROPORTION_CSV_DIR,proportion,f'{ids}.xlsx')
        
        if os.path.exists(areaProporPath):
            df3 = pd.read_excel(areaProporPath)
        else:
            print(toGreen(f're-generate prior and calculate proportion ...'))
            df3 = generate_prior_and_calculate_proportion(ids,postprocess=proportion)

        areas={'NAS-Inflammation':[],'NAS-Ballooning':[],'NAS-Steatosis':[]}
        tic=time.time()
        for jj in range(len(df2)):
            if df2['Prediction'][jj]==0:continue
            predict=df2['Prediction'][jj]
            key = PATTERNS[predict]
            tile_name=df2['tileName'][jj].split('/')[-1]
            index = df3.index[df3['tileName']==tile_name].tolist()[0]
            nuclei_proportion=df3['Proportion-nuclei'][index]
            white_proportion=df3['Proportion-white'][index]
            # chong: what area counting!!!
            if predict==1: # nuclei
                areas[key].append(nuclei_proportion)
            elif predict==2: # ballooning
                areas[key].append(white_proportion)
            elif predict==3: # steatosis
                areas[key].append(white_proportion)

    
        results['LabNo'].append(ids)
        # results['NAS-Steatosis'].append(nas_steatosis)
        # results['NAS-Inflammation'].append(nas_inflammation)
        # results['NAS-Ballooning'].append(nas_ballooning)
        results['Proportion-Steatosis'].append(np.sum(np.array(areas['NAS-Steatosis'])))
        results['Proportion-Inflammation'].append(np.sum(np.array(areas['NAS-Inflammation'])))
        results['Proportion-Ballooning'].append(np.sum(np.array(areas['NAS-Ballooning'])))

    return results

# given a slide list, it contain multiple slides, process slides in loop or multiprocess cores
def multiprocess_calculate_proportion(df,method=None,proportion=None,fold=None,cores=10):
    _df_parts = np.array_split(df, cores)
    df_parts = [x.reset_index(drop=True) for x in _df_parts]
    pool = mp.Pool(cores)
    args_list = [(df_part,method,proportion,fold) for df_part in df_parts]
    results_list = pool.starmap(singleprocess_calculate_proportion, args_list)
    results={'LabNo':[],'Proportion-Steatosis':[],'Proportion-Inflammation':[],'Proportion-Ballooning':[]}
    for ii in range(cores):
        for key in results.keys():
            results[key].extend(results_list[ii][key]) 

    return results


# three options to process five-fold p-values
def fisher_method(p_values):
    p_values = np.array(p_values)
    sum_neg_log_pvalues = -2 * np.sum(np.log(p_values))
    combined_p_value = chi2.sf(sum_neg_log_pvalues, 2*len(p_values))
    return combined_p_value


def stouffer_method(p_values):
    p_values = np.array(p_values)
    z_scores = norm.ppf(1 - p_values)
    combined_z_score = np.sum(z_scores) / np.sqrt(len(p_values))
    combined_p_value = 1 - norm.cdf(combined_z_score)
    return combined_p_value


def averaging_method(p_values):
    p_values = np.array(p_values)
    combined_p_value = 2 * np.mean(p_values)
    return combined_p_value





def calculate_spearmanr(df,proportion=None):
    spearmans_score={'Steatosis':[],'Inflammation':[],'Ballooning':[]}
    p_values={'Steatosis':[],'Inflammation':[],'Ballooning':[]}
    for item in ['Steatosis','Inflammation','Ballooning']:
        data1=df[f'NAS-{item}']
        if proportion!='none':
            data2=df[f'Proportion-{item}']/df['totalTiles']
        else:
            data2=df[f'Number-{item}']/df['totalTiles']

        spearman = stats.spearmanr(data1, data2) 
        print(toCyan(f'{item}')) 
        print(f"Spearman's correlation coefficient: {spearman.correlation}")
        print(f"P-value: {spearman.pvalue}")  
        spearmans_score[item].append(spearman.correlation)
        p_values[item].append(spearman.pvalue)
    
    return spearmans_score, p_values


def plot_box(df,proportion=None,method=None,fold=None):
    for item in ['Steatosis','Inflammation','Ballooning']:
        data1=df[f'NAS-{item}']
        if proportion!='none':
            data2=df[f'Proportion-{item}']/df['totalTiles']
        else:
            data2=df[f'Number-{item}']/df['totalTiles']
        data={'Proportion':data2, f'{item}': data1}
        new_df = pd.DataFrame(data)
        sns.catplot(x = f'{item}', y = 'Proportion', data = new_df, kind = "box", height = 4, aspect = .7)
        plt.tight_layout()
        plt.savefig(os.path.join(LOG_DIR,method,f'{item}-F{fold}-area{proportion}.png'),dpi=600)


def merge_area_proportion(orig_df,method=None,proportion=None,fold=None,cores=4):
    # results={'LabNo':[],'NAS-Steatosis':[],'NAS-Inflammation':[],'NAS-Ballooning':[],'totalTiles':[],'Number-Steatosis':[],'Number-Inflammation':[],'Number-Ballooning':[],'Proportion-Steatosis':[],'Proportion-Inflammation':[],'Proportion-Ballooning':[]}
    results={'LabNo':[],'Proportion-Steatosis':[],'Proportion-Inflammation':[],'Proportion-Ballooning':[]}
    PATTERNS=['none','NAS-Inflammation','NAS-Ballooning', 'NAS-Steatosis']
    
    df1=pd.read_excel(CSV_FILE,index_col=False).sort_values(by='LabNo',ignore_index=True)

    tic=time.time()
    if cores==1:
        results=singleprocess_calculate_proportion(df1,method=method,proportion=proportion,fold=fold)
    else:
        results=multiprocess_calculate_proportion(df1,method=method,proportion=proportion,fold=fold,cores=cores)
    print(f'merge function cost time: {time.time()-tic:.3f}')


    new_df = pd.DataFrame(results)
    # merge two excel file
    merged_df = pd.merge(orig_df,new_df,on='LabNo')

    return merged_df


        

CSV_FILE='/home/comp/chongyin/DataSets/Liver-NASH/LiverBiopsyExcels/IJCAI22-Liver-NAS-259.xlsx'
CSV_DIR='/home/comp/chongyin/DataSets/Liver-NASH/LiverBiopsyExcels'
LOG_DIR='/home/comp/chongyin/DataSets/Liver-NASH/SlidingOnWSI/'
PROPORTION_CSV_DIR='/home/comp/chongyin/DataSets/Liver-NASH/LiverBiopsyExcels/prior-proportion/'
SLIDE_DIR='/home/comp/chongyin/DataSets/Liver-NASH/LiverBiopsyPatches40X224'
PRIOR_DIR='/home/comp/chongyin/DataSets/Liver-NASH/LiverBiopsyPatches40X224Prior'

def parse_args():

    parser = argparse.ArgumentParser()
    parser.add_argument('--logDir', type=str, default='/home/comp/chongyin/DataSets/Liver-NASH/SlidingOnWSI')
    parser.add_argument('--method', type=str, default=None)
    parser.add_argument('--proportion', type=str, default='none')
    parser.add_argument('--plot', type=int, default=0)
    parser.add_argument('--cores', type=int, default=1)
    args = parser.parse_args()
    return args

def main():

    args = parse_args()

    # METHODS=['InceptionV3','SAR']
    # METHODS=['VPT','VPT-based-VQT']
    # METHODS=['Ours-D1T1000H0B0-S0-1-2-3M0-1-7-testOnD1T1000H0B0','Ours-D1T1500H0B0-S0-1-2-3M0-1-7-testOnD1T1500H0B0']
    # METHODS=['Ours-D1T2500H0B0-S0-1-2-3M0-1-7-testOnD1T2500H0B0']
    # PROPORTIONS=['D1T500H1B1']

    #results={'LabNo':[],'NAS-Steatosis':[],'NAS-Inflammation':[],'NAS-Ballooning':[],'totalTiles':[],'Number-Steatosis':[],'Number-Inflammation':[],'Number-Ballooning':[]}

    # calculate spearmanr correlation coefficient

    allfolds_spearmans_score={'Steatosis':[],'Inflammation':[],'Ballooning':[]}
    allfolds_p_values={'Steatosis':[],'Inflammation':[],'Ballooning':[]}

    print(toMagenta(f'{args.method}-Proportion:{args.proportion}'))
    for fold in range(5):
        print(toMagenta(f'F{fold}'))
        file=os.path.join(args.logDir,args.method,f'F{fold}.xlsx')
        if not os.path.exists(file):
            continue
        orig_df = pd.read_excel(file)
        if args.proportion=='none':
            df = orig_df
        else:
            df=merge_area_proportion(orig_df,proportion=args.proportion,method=args.method,fold=fold,cores=args.cores)
        spearmans_score, p_values = calculate_spearmanr(df,proportion=args.proportion)
        
        for item in allfolds_spearmans_score.keys():
            allfolds_spearmans_score[item].extend(spearmans_score[item])
            allfolds_p_values[item].extend(p_values[item])

        if args.plot: plot_box(df,proportion=args.proportion,method=args.method,fold=fold)

    print(toMagenta(f'All folds results and AVG(std)'))
    for item in allfolds_spearmans_score.keys():
        scores = np.array(allfolds_spearmans_score[item])
        avg=np.mean(scores)
        std=np.std(scores)
        print(f'{item}, allFolds scores: {scores}, Avg:{avg:.3f}, STD:{std:.3f}')

    print(toMagenta(f'Fisher method ...'))
    for item in allfolds_p_values.keys():
        pvalue = fisher_method(allfolds_p_values[item])
        print(f'{item}, allFolds pvalue: {pvalue}')

    print(toMagenta(f'Stouffer method ...'))
    for item in allfolds_p_values.keys():
        pvalue = stouffer_method(allfolds_p_values[item])
        print(f'{item}, allFolds pvalue: {pvalue}')

    print(toMagenta(f'Average method ...'))
    for item in allfolds_p_values.keys():
        pvalue = averaging_method(allfolds_p_values[item])
        print(f'{item}, allFolds pvalue: {pvalue}')
  



if __name__ == '__main__':
    main()
