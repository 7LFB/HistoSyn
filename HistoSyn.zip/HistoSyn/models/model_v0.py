from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import logging
import time
from pathlib import Path

import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

from pdb import set_trace as st

import timm


class Biopsy(nn.Module):
  
    def __init__(self,args):
        super(Biopsy, self).__init__()

        self.encoder = timm.create_model(args.proj,pretrained=True,num_classes=0,global_pool='avg')
        self.classifier = nn.Sequential(
            nn.Linear(args.hidden_dim, 256), 
            nn.ReLU(inplace=True),        
            nn.Dropout(0.5),               
            nn.Linear(256, args.num_classes) 
        )

    def forward(self, x):

        hidden = self.encoder(x)
    
        logits = self.classifier(hidden)

        return logits




      



