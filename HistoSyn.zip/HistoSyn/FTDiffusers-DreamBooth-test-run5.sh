root_pretrained_model_name_or_path='/home/comp/chongyin/checkpoints/XDataExpand'
root_output_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/SyntheticSamples'
est_dist_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/clean_structures'
caption_list_folder='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/CaptionLists/histomorphology-focused-v2'
SDM='stable-diffusion-v1-5'
num_samples_per_prompt=1
num_prompts_per_class=1
build_prompt_method=1
read_prompts_from_txts=0
base_model_name='ours-balance-v2'

for step in 400
do
for decorate_txt_prompts in 0
do
for num_per_category in 28
do
for fold in 0 1 2 3 4
do
for cmode in 'mixed'
do
CUDA_VISIBLE_DEVICES=1 python FTDiffusers/inference_dreambooth.py \
 --pretrained_model_name_or_path "${root_pretrained_model_name_or_path}/${SDM}/${base_model_name}-${num_per_category}-${cmode}-RareToken${decorate_txt_prompts}-cellPoseSeg-fold${fold}/${step}"\
 --output_dir "${root_output_dir}/${SDM}/${base_model_name}-${num_per_category}-RareToken${decorate_txt_prompts}-cellPoseSeg-fold${fold}"\
 --num_samples_per_prompt $num_samples_per_prompt\
 --num_prompts_per_class $num_prompts_per_class\
 --est_dist_dir $est_dist_dir\
 --build_prompt_method $build_prompt_method\
 --concepts_list "${caption_list_folder}/${num_per_category}/train_fold_${fold}_balance_${num_per_category}_cellPoseSeg.json"\
 --read_prompts_from_txts $read_prompts_from_txts\
 --fold $fold\
 --cmode $cmode\
 --decorate_txt_prompts $decorate_txt_prompts
done
done
done
done
done