
for cmode in 'others' 'inflammation' 'ballooning' 'steatosis'
do
CUDA_VISIBLE_DEVICES=0 python QualityEvaluation/draw_figure.py \
 --cmode $cmode
done