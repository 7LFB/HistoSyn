root_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/SyntheticSamples/stable-diffusion-v1-5/ours-balance-v2-28-RareToken0-template3'

for fold in 0 1 2 3 4
do
CUDA_VISIBLE_DEVICES=1 python FTDiffusers/generate_file_list.py \
 --output_dir "${root_dir}-fold${fold}/"\
 --fold $fold
done
