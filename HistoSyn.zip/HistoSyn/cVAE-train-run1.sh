
for ratio in 0.01
do
CUDA_VISIBLE_DEVICES=2 python VAENMF/train_cVAE.py\
 --ratio $ratio
done
