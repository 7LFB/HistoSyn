model_name_pre='runwayml'
model_name_card='stable-diffusion-v1-5'
root_instance_dir="/home/comp/chongyin/DataSets/LiverNASTiles-20230727/clean_structures"
root_class_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/ClassSamples/'
caption_list_folder='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/CaptionLists/histomorphology-focused-v2'
root_output_dir="/home/comp/chongyin/checkpoints/XDataExpand/"
with_prior_preservation=0
prior_loss_weight=0.0
resolution=512
train_batch_size=4
gradient_accumulation_steps=1
learning_rate=5e-6
lr_scheduler="constant"
lr_warmup_steps=0
max_train_steps=400
base_model_name='ours-balance-v2'

for num_per_category in 28
do
for caption_template_type in 3
do
for read_prompts_from_txts in 0
do
for decorate_txt_prompts in 0
do
for fold in 0 1 2 3 4
do
for cmode in 'mixed'
do
CUDA_VISIBLE_DEVICES=1 python FTDiffusers/train_dreambooth.py\
 --pretrained_model_name_or_path "${model_name_pre}/${model_name_card}"\
 --instance_data_dir "${root_instance_dir}"\
 --output_dir "${root_output_dir}/${model_name_card}/${base_model_name}-${num_per_category}-mixed-RareToken${decorate_txt_prompts}-template${caption_template_type}-fold${fold}"\
 --resolution $resolution\
 --train_batch_size $train_batch_size\
 --gradient_accumulation_steps $gradient_accumulation_steps\
 --learning_rate $learning_rate\
 --lr_scheduler $lr_scheduler\
 --lr_warmup_steps $lr_warmup_steps\
 --max_train_steps $max_train_steps\
 --concepts_list "${caption_list_folder}/${num_per_category}/train_fold_${fold}_balance_${num_per_category}_template_${caption_template_type}.json"\
 --read_prompts_from_txts $read_prompts_from_txts\
 --prior_loss_weight $prior_loss_weight\
 --with_prior_preservation $with_prior_preservation\
 --cmode $cmode\
 --decorate_txt_prompts $decorate_txt_prompts
done
done
done
done
done
done
 