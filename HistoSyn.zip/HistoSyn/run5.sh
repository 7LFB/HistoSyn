data_version=0
logdir_name='resnet50-SDv15-Syn280NDPP1'
real_data_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/clean_structures/'
real_file_list_folder='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/CaptionLists'
syn_data_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/SyntheticSamples/stable-diffusion-v1-5'
syn_file_list_folder='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/SyntheticSamples/stable-diffusion-v1-5'
test_file_list_folder='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/CVFold'
base_syn_data_method='ours-balance-v2'

for num_per_category in 28
do
for decorate_txt_prompts in 0
do
for real_ratio in 1.0
do
for syn_ratio in 1.0
do
for real_syn_mode in 2
do
for fold in 0 1 2 3 4
do
CUDA_VISIBLE_DEVICES=1 python train.py\
 --model_name "${base_syn_data_method}-${num_per_category}-RareToken${decorate_txt_prompts}-realSynMode${real_syn_mode}-real${real_ratio}syn${syn_ratio}-cellPoseSeg"\
 --real_syn_mode $real_syn_mode\
 --fold $fold\
 --data_version $data_version\
 --logdir_name $logdir_name\
 --real_file_list_folder "${real_file_list_folder}/histomorphology-focused-v2/${num_per_category}"\
 --syn_file_list_folder "${syn_file_list_folder}/${base_syn_data_method}-${num_per_category}-RareToken${decorate_txt_prompts}-cellPoseSeg-fold${fold}"\
 --test_file_list_folder $test_file_list_folder\
 --syn_data_dir "${syn_data_dir}/${base_syn_data_method}-${num_per_category}-RareToken${decorate_txt_prompts}-cellPoseSeg-fold${fold}"\
 --real_data_dir $real_data_dir\
 --real_ratio $real_ratio\
 --syn_ratio $syn_ratio
done
done
done
done
done
done
