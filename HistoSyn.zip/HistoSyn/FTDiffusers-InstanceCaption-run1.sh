data_version=0

# imgs_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/clean_structures'
# file_list_folder='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/CVFold/'
# caption_list_folder='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/CaptionLists/histomorphology-focused'
imgs_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/clean_structures'
file_list_folder='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/CVFold/'
caption_list_folder='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/CaptionLists/baseline'
only_kmeans=0

for num_per_category in 28 140
do
for fold in 0 1 2 3 4
do
for clusters in 10
do
for caption_template_type in 0
do
CUDA_VISIBLE_DEVICES=1 python FTDiffusers/generate_caption_list.py \
 --data_version $data_version\
 --fold $fold\
 --num_per_category $num_per_category\
 --imgs_dir $imgs_dir\
 --file_list_folder $file_list_folder\
 --caption_list_folder "${caption_list_folder}/${num_per_category}"\
 --clusters $clusters\
 --caption_template_type $caption_template_type\
 --only_kmeans $only_kmeans
done
done
done
done