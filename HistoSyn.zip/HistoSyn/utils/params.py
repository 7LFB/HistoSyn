from datetime import datetime
import argparse
import os


ROOT_DIR='/home/comp/chongyin'
subdir = datetime.strftime(datetime.now(), '%Y%m%d-%H%M%S')
SNAPSHOT_DIR = ROOT_DIR+'/checkpoints/XDataExpand/'+subdir+'/'

def parse_args():
    parser = argparse.ArgumentParser(description='Train network')

    # dataset
    parser.add_argument('--img_h',default=224,type=int)
    parser.add_argument('--img_w',default=224,type=int)
    parser.add_argument('--augment',default=0,type=int)
    parser.add_argument('--auto_augment',default=0,type=int)
    parser.add_argument('--num_classes',default=4,type=int)

    # model
    parser.add_argument('--proj',default='resnet50',type=str)
    parser.add_argument('--model_name',default='resnet50',type=str)
    parser.add_argument('--mversion',default=0,type=int)
    parser.add_argument('--hidden_dim',default=2048,type=int)
    parser.add_argument('--freeze_pattern',default='',type=str)

    # training
    parser.add_argument('--lr',default=1e-1,type=float)
    parser.add_argument('--momentum',default=0.9,type=float)
    parser.add_argument('--weight_decay',default=1e-5,type=float)
    parser.add_argument('--start_epoch',default=0,type=int)
    parser.add_argument('--num_epochs',default=100,type=int)
    parser.add_argument('--ckpt_path',default='',type=str)
    # training data setting
    parser.add_argument('--real_syn_mode',default=1,type=int)
    parser.add_argument('--real_ratio',default=1.0,type=float)
    parser.add_argument('--syn_to_real_ratio',default=1.0,type=float)
    parser.add_argument('--syn_ratio',default=1.0,type=float)
    parser.add_argument('--data_version',default=0,type=int)
    parser.add_argument('--fold',default=0,type=int)
    parser.add_argument('--ratio',default=1.0,type=float)
    # training data dir
    parser.add_argument('--test_file_list_folder',type=str,default=None)
    parser.add_argument('--real_file_list_folder',type=str,default=None)
    parser.add_argument('--syn_file_list_folder',type=str,default=None)
    parser.add_argument('--real_data_dir',default=None,type=str)
    parser.add_argument('--syn_data_dir',default=None,type=str)


    # experiment
    parser.add_argument('--snapshot_dir',default=SNAPSHOT_DIR,type=str)
    parser.add_argument('--num_gpus',default=1,type=int)
    parser.add_argument('--logdir_name',default=None,type=str)
    parser.add_argument('--seed',default=1024,type=int)
    parser.add_argument('--batch_size',default=16,type=int)
    parser.add_argument('--batch_size_for_test',default=1,type=int)
    parser.add_argument('--workers',default=16,type=int)

    # test on slide
    parser.add_argument('--resume_from',default=None,type=str)
    parser.add_argument('--resume_keywords',default=None,type=str)
    parser.add_argument('--output_folder',default='/home/comp/chongyin/DataSets/Liver-NASH/SlidingOnWSI/SynthesisMethods',type=str)



    
   

    
    args = parser.parse_args()

    return args
