import umap
import numpy as np
from scipy.spatial.distance import jensenshannon
from scipy.stats import wasserstein_distance, energy_distance, norm
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.mixture import GaussianMixture
import matplotlib.pyplot as plt

def calculate_umap_distance(data1, data2, method='wasserstein', n_neighbors=15, min_dist=0.1, n_components=2, metric='euclidean',plot_save_path=None):
    # Fit UMAP
    umap_model = umap.UMAP(n_neighbors=n_neighbors, min_dist=min_dist, n_components=n_components, metric=metric)
    combined_data = np.vstack((data1, data2))
    umap_result = umap_model.fit_transform(combined_data)
    
    # Split the results back into two samples
    umap_data1 = umap_result[:len(data1), :]
    umap_data2 = umap_result[len(data1):, :]

    # Calculate the distance between the two distributions
    if method == 'wasserstein': #[0,+oo)
        distance = wasserstein_distance(umap_data1.ravel(), umap_data2.ravel())
    elif method == 'jensenshannon':
        # For Jensen-Shannon, we need to estimate the probability distributions (e.g., using histograms)
        p_dist_1, _ = np.histogram(umap_data1, bins=30, density=True)
        p_dist_2, _ = np.histogram(umap_data2, bins=30, density=True)
        distance = jensenshannon(p_dist_1, p_dist_2)
    elif method == 'energy':
        distance = energy_distance(umap_data1.ravel(), umap_data2.ravel())
    elif method == 'cosine':
        # Cosine similarity is for vectors; here we treat each sample as a vector
        # Note: This is not a distribution distance but a sample-wise distance measure
        similarity = cosine_similarity(umap_data1.mean(axis=0).reshape(1, -1), umap_data2.mean(axis=0).reshape(1, -1))
        distance = 1 - similarity  # Convert similarity to distance
    else:
        raise ValueError("Unsupported method. Choose from 'wasserstein', 'jensenshannon', 'energy', or 'cosine'.")
    
    # Plot the results with different colors
    plt.scatter(umap_data1[:, 0], umap_data1[:, 1], alpha=0.5, label='Real Data')
    plt.scatter(umap_data2[:, 0], umap_data2[:, 1], alpha=0.5, label='Synthetic Data')
    # plt.title('UMAP projection of two samples')
    plt.xlabel('UMAP dimension 1',fontsize=16)
    plt.ylabel('UMAP dimension 2',fontsize=16)
    # Set tick labels font size
    plt.xticks([])
    plt.yticks([])
    plt.legend(fontsize=14)
    # plt.show()
    plt.savefig(plot_save_path, 
            bbox_inches ="tight", 
            pad_inches = 0.1, 
            transparent = False)
    return distance

# Example usage:
# Replace 'embeddings1' and 'embeddings2' with your actual data samples
# Choose a method: 'wasserstein', 'jensenshannon', 'energy', or 'cosine'
# distance = calculate_umap_distance(embeddings1, embeddings2, method='wasserstein')
# print(f"The distance between the two distributions is: {distance}")

# Function to plot GMMs
def plot_gmm(gmm, label, color):
    # Create an array of evenly spaced values over the range of interest
    x = np.linspace(-5, 5, 1000)
    # Calculate the PDF of each component
    logprob = gmm.score_samples(x.reshape(-1, 1))
    responsibilities = np.exp(logprob)
    pdf = np.exp(responsibilities)
    plt.fill_between(x, pdf, alpha=0.5, color=color, label=f'GMM {label}')
    plt.legend()

def plot_gmm_components(gmm, label, color):
    x = np.linspace(-5, 5, 1000)
    for i, (mean, cov) in enumerate(zip(gmm.means_, gmm.covariances_)):
        # For each component, plot the Gaussian distribution
        pdf = norm(mean[0], np.sqrt(cov[0][0])).pdf(x)
        plt.plot(x, pdf, label=f'{label} Component {i+1}', color=color)
        plt.fill_between(x, pdf, alpha=0.3, color=color)

def gmm_distance(gmm_p, gmm_q, metric='kl', n_samples=10000, plot_type=0,plot_save_path=None):
    # Check if the GMMs are fitted
    if not hasattr(gmm_p, 'converged_') or not gmm_p.converged_:
        raise ValueError("GMM p is not fitted yet.")
    if not hasattr(gmm_q, 'converged_') or not gmm_q.converged_:
        raise ValueError("GMM q is not fitted yet.")


    if plot_type==1:
        plot_gmm(gmm_p, 'P', 'blue')
        plot_gmm(gmm_q, 'Q', 'red')
    elif plot_type==2:
        # Plotting the GMM components
        plot_gmm_components(gmm_p, 'P', 'blue')
        plot_gmm_components(gmm_q, 'Q', 'red')

    plt.title('Gaussian Mixture Model Components')
    plt.xlabel('Value')
    plt.ylabel('Density')
    plt.legend()
    plt.savefig(plot_save_path, 
            bbox_inches ="tight", 
            pad_inches = 0.1, 
            transparent = False)

    # Calculate the distance between the two GMMs based on the specified metric
    if metric == 'kl':
        # KL divergence calculation would go here
        pass  # Replace with actual KL divergence calculation code
    elif metric == 'wasserstein':
        # Draw samples from both GMMs
        samples_p = gmm_p.sample(n_samples)[0]
        samples_q = gmm_q.sample(n_samples)[0]
        
        # Calculate Wasserstein distance between the two sets of samples
        return wasserstein_distance(samples_p.ravel(), samples_q.ravel())
    else:
        raise ValueError("Unsupported metric specified.")

# # Example usage:
# # Create two GMM objects with sklearn
# gmm_p = GaussianMixture(n_components=2, means_init=np.array([[0], [2]]), 
#                         precisions_init=np.array([[[1]], [[1]]]))
# gmm_q = GaussianMixture(n_components=2, means_init=np.array([[0], [2]]), 
#                         precisions_init=np.array([[[1.5]], [[1.5]]]))

# # Fit GMMs if they are not already fitted (you would pass fitted GMMs in practice)
# gmm_p.fit(np.random.randn(1000, 1))
# gmm_q.fit(np.random.randn(1000, 1))

# # Plot and calculate distance
# distance = gmm_distance(gmm_p, gmm_q, metric='wasserstein')
# print(f"The Wasserstein distance between the two GMMs is: {distance}")


