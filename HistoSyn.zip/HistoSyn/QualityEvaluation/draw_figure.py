import matplotlib.pyplot as plt
import argparse
import os
import glob

def draw_and_save_bar_figure(values, file_name):
    """
    Draws a bar figure for a given list of values and saves it to a file.

    Parameters:
    values (list): A list of numerical values for the bar chart.
    file_name (str): The name of the file to save the figure.
    """
    # Set up the figure and axis
    plt.figure(figsize=(10, 5))
    bars = plt.bar(range(len(values)), values)

    # Set the y-axis range from -1 to 1
    plt.ylim(-1, 1)

    # Draw a horizontal line at y=0 to represent the x-axis
    plt.axhline(0, color='black', linewidth=0.8)

    # Add labels to each bar
    for bar in bars:
        y_val = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2, y_val, f'{y_val:.4f}', 
                 ha='center', va='bottom' if y_val > 0 else 'top', fontsize=18)

    # Set labels and title
    # plt.xlabel('Evaluation metrics',fontsize=18)
    # plt.ylabel('pearson correlation coefficient',fontsize=18)
    # plt.title(cmode, fontsize=16, pad=10)


    # Customize x-axis with index numbers
    xtick_labels = ['FID', '$HistD_1$', '$HistD_2$', '$HistD_3$', '$HistD_4$', '$HistD_5$', '$HistD_6$', '$HistD_7$']
    plt.xticks(range(len(values)),xtick_labels,fontsize=20)
    plt.yticks(fontsize=20)

    # Show grid
    plt.grid(axis='y', linestyle='--', alpha=0.7)

    # Remove top and right borders
    plt.gca().spines['top'].set_visible(False)
    plt.gca().spines['right'].set_visible(False)

    # Save the figure
    plt.savefig(file_name, bbox_inches='tight')

    # Show the figure
    # plt.show()

def parse_args(input_args=None):
    parser = argparse.ArgumentParser(description="Simple example of a training script.")
    # feature embedding
    parser.add_argument("--save_dir",type=str,default='/home/comp/chongyin/PyTorch/XDataExpansion/Results/figures')
    parser.add_argument('--cmode',type=str,default='others')


    args = parser.parse_args()

    return args



def main():
    args=parse_args()
    # Example usage:
    Data={'others':[0.1261, 0.349, 0.026, -0.053, 0.344, -0.898, -0.183,-0.7900],
          'inflammation':[0.5875,-0.0538,-0.3066,0.63174,0.4616,0.3357,0.6293,-0.0679],
          'ballooning':[0.5407,0.09492,-0.04714,0.0974,0.5372,-0.7883,0.2768,-0.9521],
          'steatosis':[-0.3531,0.44267,0.1396,-0.3637,-0.1422,-0.6573,-0.599,-0.2960]}
    
    save_path=os.path.join(args.save_dir,f'{args.cmode}-metrics.png')
    draw_and_save_bar_figure(Data[args.cmode], save_path)


if __name__ == '__main__':
    main()
