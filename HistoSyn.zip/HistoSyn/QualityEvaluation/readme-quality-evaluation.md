# Quality evaluation from fidelity and diversity using UMAP feature space


# Quality evaluation from inspecting attribute distribution (gmm)


# Quality evaluation from calculate the distance between two distributions.