import cv2
import numpy as np
import random
import os
import glob

import torch
from torch.nn import functional as F
from torch.utils import data
from torchvision import transforms
from imgaug import augmenters as iaa
from torchmetrics.image.fid import FrechetInceptionDistance
from skimage.color import rgb2hed
import pandas as pd
import glob
import argparse
import random
from PIL import Image
import timm
import warnings
warnings.filterwarnings("ignore")
from scipy.stats import wasserstein_distance
from pdb import set_trace as st
import sys
sys.path.append('/home/comp/chongyin/lib/HIPT/')
sys.path.append('/home/comp/chongyin/lib/HIPT/HIPT_4K/')
from HIPT_4K.hipt_4k import HIPT_4K
from HIPT_4K.hipt_model_utils import eval_transforms
sys.path.append('/home/comp/chongyin/PyTorch/XDataExpansion/')
from utils.dist_distance import *
from utils.util import *
from utils.tools import *


MEAN=np.array([0.485, 0.456, 0.406])
STD=np.array([0.229, 0.224, 0.225])

def opencv2pil(img):
    rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    # Create a PIL image from the OpenCV image
    pil_img = Image.fromarray(rgb_img) 

    return pil_img

def cv2_imread_resize(path,mode,resize=(224,224)):
    x=cv2.imread(path,mode)
    x=cv2.resize(x, (resize[0], resize[1]))
    return x

def _read_image(path, resize=(224, 224), pil_format=0):
    img=cv2_imread_resize(path,1,resize=resize)
    if pil_format: 
        img = opencv2pil(img) 
    return img

def _read_image_collections_into_tensor(img_dir,file_list,resize=(299,299)):
    transform = transforms.Compose([
        transforms.Resize(resize),  # Resize images to the same size for batching
        transforms.ToTensor()  # Convert images to tensors
    ])
    tensors=[]
    for file in file_list:
        img = Image.open(os.path.join(img_dir,file))
        img_tensor=transform(img)
        tensors.append(img_tensor)
    
    batch_tensor = torch.stack(tensors)

    return batch_tensor
    


def collect_embeds_from_imgs(myProjector,base_transforms,proj_type,img_dir,files):

    feats = []
    for file in files:
        img = Image.open(os.path.join(img_dir,file))
        if proj_type == 'vit16small':
            x = eval_transforms()(img).unsqueeze(dim=0)
            feat = myProjector.forward_model256_features(x)# 1 x (1+16x16) x 384
        else:
            imgTensor=base_transforms(img)
            feat=myProjector.forward_features(imgTensor.unsqueeze(0).cuda()) # 1 x (1+16x16) x 384 or # 1x512xhxw
        if proj_type == 'vit16small' or proj_type == 'lunit-dino':
            feat = feat[:,:1,:]
            feat = torch.squeeze(feat)
        else:
            pass
        
        feat=feat.detach().cpu().numpy()
        feats.append(feat)
    
    feats = np.array(feats)
    
    return feats


def read_txt(path,cmode='mixed'):
    with open(path,'r') as f:
        lines_=f.readlines()
    lines= [x.strip().split(' ')[0] for x in lines_]
    if cmode != 'mixed':
        lines = [x for x in lines if cmode in x]
    return lines

def generate_data_list_txt(img_dir,sub_types,fold):
    f = open(os.path.join(img_dir,f'train_fold_{fold}.txt'),'w')

    for item in sub_types:
        files = glob.glob(os.path.join(img_dir,item,'*.png'))
        for file in files:
            line=f'{item}/{os.path.basename(file)} {sub_types.index(item)}\n'
            f.write(line)

    f.close()


def calculate_dataset_props(img_dir,file_list,args):
    dataset_means=[]
    dataset_stds=[]
    for index, file in enumerate(file_list):
        print('\r',f'{index}/{len(file_list)}: {file}',end='')
        props_dict=generate_prior_and_calculate_props(img_dir,file,args.props_index_str_s,args.props_index_str_m,args)

        single_sample_means=[]
        single_sample_stds=[]

        for index, item in enumerate(props_dict['spatial_values']):
            mean, std = calculate_mean_std_from_list(item,props_dict['spatial_counts'][index])
            single_sample_means.append(mean)
            single_sample_stds.append(std)

        for index, item in enumerate(props_dict['morpho_values']):
            mean, std = calculate_mean_std_from_histogram(item,props_dict['morpho_counts'][index])
            single_sample_means.append(mean)
            single_sample_stds.append(std)

        dataset_means.append(single_sample_means)
        dataset_stds.append(single_sample_stds)
        

    return dataset_means, dataset_stds

        # # mixture gaussian estimation
        # if args.est_distribution:
        #     gmm = GaussianMixture(n_components=args.n_components, random_state=0)
        #     data=np.array(class_means)
        #     # Fit the model to the data
        #     gmm.fit(data.reshape(-1, args.n_components))
    
        #     joblib.dump(gmm, os.path.join(data_dir,f'{subtype}_gmm_model.pkl'))




def parse_args(input_args=None):
    parser = argparse.ArgumentParser(description="Simple example of a training script.")
    # feature embedding
    parser.add_argument("--proj",type=str,default='lunit-dino')
    parser.add_argument('--emb_sample_number',type=int, default=40)

    # data dir
    parser.add_argument("--real_data_dir",type=str,default=None)
    parser.add_argument("--syn_data_dir",type=str,default=None)
    parser.add_argument("--caption_list_dir",type=str,default=None)

    parser.add_argument("--cmode",type=str,default='others')
    parser.add_argument("--data_version",type=int,default=0)

    # gmm distribution dir
    parser.add_argument("--est_dist_dir",type=str,default='')
    parser.add_argument("--est_distribution",type=int,default=0)


    # eval distribution distance
    parser.add_argument("--distance_method",type=str,default='wasserstein')

    parser.add_argument('--plot_save_dir',type=str,default='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/SyntheticSamples/stable-diffusion-v1-5/quality_evaluation')

    parser.add_argument("--calc_umap",type=int,default=0)
    parser.add_argument("--calc_fid",type=int,default=0)
    parser.add_argument("--calc_distribution_distance",type=int,default=0)

    parser.add_argument("--fold",type=int,default=0)
    parser.add_argument('--model_name',type=str,default=int)

    parser.add_argument('--sample_number',default=10,type=int)
    parser.add_argument('--props_index_str_s',default='0-1-2-3',type=str)
    parser.add_argument('--props_index_str_m',default='0-1-7',type=str)
    parser.add_argument('--kfunc_version', default='S0V0', type=str)
    parser.add_argument('--prior_nuclei', default=1, type=int)
    parser.add_argument('--prior_white', default=1, type=int)
    parser.add_argument('--max', default=1, type=int)
    parser.add_argument('--filter', default=0.1, type=float)
    parser.add_argument('--dilate', default=0, type=int)
    parser.add_argument('--se_kernel', default=11, type=int)
    parser.add_argument('--area_thd', default=0, type=int)
    parser.add_argument('--convex_hull', default=0, type=int)
    parser.add_argument('--clear_border', default=0, type=int)


    args = parser.parse_args()

    return args




def main():
    args = parse_args()
    # feature embedding setting
    if args.proj == 'vit16small':
        myProjector = HIPT_4K()
    elif args.proj=='lunit-dino':
        myProjector=timm.create_model(model_name="hf-hub:1aurent/vit_small_patch16_224.lunit_dino",pretrained=True,features_only=False,num_classes=0,global_pool='').cuda()
        # get model specific transforms (normalization, resize)
        data_config = timm.data.resolve_model_data_config(myProjector)
        base_transforms = timm.data.create_transform(**data_config, is_training=False)
    else:
        myProjector=timm.create_model(args.proj,pretrained=True,features_only=False,num_classes=0,global_pool='').cuda()
        base_transforms_list=[transforms.ToTensor(), transforms.Normalize(mean = MEAN, std = STD)]
        base_transforms=transforms.Compose(base_transforms_list)
    
    myProjector.eval() # chong: important!

    if args.data_version==0:
        if args.est_dist_dir==None: args.est_dist_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/clean_structures/'
        if args.real_data_dir==None: args.real_data_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/clean_structures/'
        if args.syn_data_dir==None: args.syn_data_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/SyntheticSamples/stable-diffusion-v1-5/'
        if args.plot_save_dir==None: args.plot_save_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/SyntheticSamples/stable-diffusion-v1-5/quality_evaluation/'
        SUB_TYPES=['others','inflammation','ballooning', 'steatosis']
    elif args.data_version==1:
        pass
    elif args.data_version==2:
        if args.est_dist_dir == None: args.est_dist_dir='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/'
        if args.real_data_dir==None: args.real_data_dir='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/'
        if args.syn_data_dir==None: args.syn_data_dir='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/SyntheticSamples/stable-diffusion-v1-5/'
        if args.plot_save_dir==None: args.plot_save_dir='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/SyntheticSamples/stable-diffusion-v1-5/quality_evaluation/'
        SUB_TYPES=['normal_he_mouse_liver','NAFLD_anomaly_he_mouse_liver']
    elif args.data_version==3: # PCam
        pass
    
    # in case there is no train_fold_.txt
    real_data_list = read_txt(os.path.join(args.caption_list_dir,f'train_fold_{args.fold}.txt'),cmode=args.cmode)

    if not os.path.exists(os.path.join(args.syn_data_dir,f'train_fold_{args.fold}.txt')):
        generate_data_list_txt(args.syn_data_dir,SUB_TYPES,args.fold)
    syn_data_list = read_txt(os.path.join(args.syn_data_dir,f'train_fold_{args.fold}.txt'),cmode=args.cmode)
    
    if args.calc_umap:
        print(toGreen('calculate UMAP for real/syn data...'))
        # read real/synthesis images and get embeddings
        random.seed(1024)
        # real_files = random.sample(glob.glob(os.path.join(args.real_data_dir,args.cmode,'*.png')),args.emb_sample_number)
        # syn_files = random.sample(glob.glob(os.path.join(args.syn_data_dir,args.syn_data_subfolder,args.cmode,'*.png')),args.emb_sample_number)

        real_feats = collect_embeds_from_imgs(myProjector,base_transforms,args.proj,args.real_data_dir,real_data_list)
        syn_feats = collect_embeds_from_imgs(myProjector,base_transforms,args.proj,args.syn_data_dir,syn_data_list)

        plot_save_path=os.path.join(args.plot_save_dir,f'{args.model_name}-{args.cmode}-real-syn-umap.png')
        distance=calculate_umap_distance(real_feats, syn_feats, method=args.distance_method, n_neighbors=15, min_dist=0.1, n_components=2, metric='euclidean',plot_save_path=plot_save_path)
        print(toCyan(f'{args.distance_method} distance (Real-Syn) on {args.cmode}: {distance:.3f}'))
        
    if args.calc_fid:
        # calculate FID score
        print(toGreen('calculate FID score for real/syn data...'))
        fid = FrechetInceptionDistance(feature=64,normalize=True)

        real_batch_data=_read_image_collections_into_tensor(args.real_data_dir,real_data_list)
        syn_batch_data=_read_image_collections_into_tensor(args.syn_data_dir,syn_data_list)

        fid.update(real_batch_data,real=True)
        fid.update(syn_batch_data,real=False)
        fid_score=fid.compute()
        print(toCyan(f'Real VS Synthetic ({args.model_name}) FID: {fid_score:.3f}'))

      
    if args.calc_distribution_distance:
        # read real/synthesis gmm distributions
        print(toGreen('calculate distance between two attributes distribution for real/syn data...'))
        real_data_means,_ = calculate_dataset_props(args.real_data_dir,real_data_list,args=args)
        syn_data_means,_ = calculate_dataset_props(args.syn_data_dir,syn_data_list,args=args)

        array1 = np.array(real_data_means)
        array2 = np.array(syn_data_means)

        distances=[]
        means=[]
        stds=[]

        for col_index in range(array1.shape[-1]):
            single_distance = wasserstein_distance(array1[:,col_index], array2[:,col_index])
            single_mean1 = np.mean(array1[:,col_index])
            single_mean2 = np.mean(array2[:,col_index])
            single_std1 = np.std(array1[:,col_index])
            single_std2 = np.std(array2[:,col_index])
            means.append([single_mean1,single_mean2])
            stds.append([single_std1,single_std2])

            distances.append(single_distance)

        print(toCyan(f'Real VS Synthetic ({args.model_name}) AttDistriDistance: {distances}'))
        print(toCyan(f'Real VS Synthetic ({args.model_name}) Means: {means}'))
        print(toCyan(f'Real VS Synthetic ({args.model_name}) Stds: {stds}'))
        



       









if __name__ == '__main__':
    main()