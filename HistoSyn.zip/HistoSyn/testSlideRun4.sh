ROOT_DIR='/home/comp/chongyin/checkpoints/XDataExpand'
subfolder=''


for base_model_name in 'baseline-balance'
do
for decorate_txt_prompts in 0
do
for real_syn_mode in 2
do
for num_per_category in 28
do
for fold in 0 1 2 3 4
do
CUDA_VISIBLE_DEVICES=3 python testSlide.py\
 --resume_from "${ROOT_DIR}"\
 --resume_keywords "F${fold}*${base_model_name}-${num_per_category}-RareToken${decorate_txt_prompts}-realSynMode${real_syn_mode}*"\
 --model_name "${base_model_name}-${num_per_category}-RareToken${decorate_txt_prompts}-realSynMode${real_syn_mode}"\
 --fold $fold
done
done
done
done
done
