
real_data_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/clean_structures'
syn_data_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/SyntheticSamples/stable-diffusion-v1-5'
caption_list_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/CaptionLists'
base_model_name='morph-enriched-balance'
caption_list_subfolder='morphology-enriched'

calc_umap=0
calc_fid=0
calc_distribution_distance=0

for decorate_txt_prompts in 0
do
for num_per_category in 28
do
for data_version in 0
do
for fold in 0 1 2 3 4
do
for cmode in 'mixed'
do
CUDA_VISIBLE_DEVICES=1 python QualityEvaluation/evaluate_real_synthesis_data.py \
 --cmode $cmode\
 --data_version $data_version\
 --syn_data_dir "${syn_data_dir}/${base_model_name}-${num_per_category}-RareToken${decorate_txt_prompts}-fold${fold}"\
 --real_data_dir $real_data_dir\
 --caption_list_dir "${caption_list_dir}/${caption_list_subfolder}/${num_per_category}"\
 --calc_umap $calc_umap\
 --calc_fid $calc_fid\
 --calc_distribution_distance $calc_distribution_distance\
 --model_name "${base_model_name}-${num_per_category}-RareToken${decorate_txt_prompts}-fold${fold}"\
 --fold $fold
done
done
done
done
done