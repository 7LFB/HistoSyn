
for ratio in 0.01
do
CUDA_VISIBLE_DEVICES=2 python VAENMF/train_NMF.py\
 --ratio $ratio
done
