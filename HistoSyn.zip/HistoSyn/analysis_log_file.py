import os
import cv2
import re
import numpy as np
import random
from skimage.color import rgb2hed
import pandas as pd
import glob
import timm
import random
import seaborn as sns
import argparse
import matplotlib.pyplot as plt
from pdb import set_trace as st
import re
from utils.tools import *
from utils.metrics import *
import warnings
warnings.filterwarnings("ignore")

# convert to colored strings
import termcolor
def toRed(content): return termcolor.colored(content,"red",attrs=["bold"])
def toGreen(content): return termcolor.colored(content,"green",attrs=["bold"])
def toBlue(content): return termcolor.colored(content,"blue",attrs=["bold"])
def toCyan(content): return termcolor.colored(content,"cyan",attrs=["bold"])
def toYellow(content): return termcolor.colored(content,"yellow",attrs=["bold"])
def toMagenta(content): return termcolor.colored(content,"magenta",attrs=["bold"])


def parse_args():

    parser = argparse.ArgumentParser()
    parser.add_argument('--key', type=str, default='str')
    parser.add_argument('--log', type=str, default='resnet50-SDv15-Data256.txt')
    args = parser.parse_args()
    return args


def main():

    args = parse_args()


    LOG_FILE = os.path.join('/home/comp/chongyin/PyTorch/XDataExpansion/log',args.log)

    METRICS=['Accuracy', 'Specificity', 'Recall', 'F1', 'AUC']
    tplt = "{0:^10}\t{1:^10}\t{2:^10}\t{3:^10}\t{4:^10}"
    f = open(LOG_FILE)
    lines = f.readlines()
    all_results={}
    for kk, _ in enumerate(lines):
        if 'Accuracy' in lines[kk]:
            line = lines[kk]
            ss = line.split(':')

            fold = ss[0].split('-')[0]
            name = '-'.join(ss[0].split('-')[1:-1])
            name = re.sub(r'-fold\d-', '', name)

            if not re.search(args.key,line):
                continue
            # extract avgclass evaluation metricx: 
            avgclass_result=[]
            for item in METRICS:
                try:
                    result = re.findall(f'{item}:[\d\.\d]+', line)[0].split(':')[-1]
                except:
                    st()
                result = np.float32(result)
                avgclass_result.append(result)
            # extract multiclass evaluation metrics: specificity, recall, f1, auc
            multiclass_result=[]
            if 'one-vs-rest' in lines[kk+1]:
                for ii in range(2,6): # rows 2-6 
                    strDigts=re.findall(r'[\d\.\d]+',lines[kk+ii])
                    digts = [float(x) for x in strDigts]
                    multiclass_result.append(digts)
            # extract confusion matrix
            cm_result=[]
            num_classes=np.array(multiclass_result).shape[-1]
            if 'Confusion Matrix' in lines[kk+6]:
                for ii in range(7,7+num_classes): # rows 7-(7+num class)
                    strDigts=re.findall(r'[\d\.\d]+',lines[kk+ii])
                    digts = [float(x) for x in strDigts]
                    cm_result.append(digts)


            if name not in all_results:
                all_results[name]={'AvgClasses':[],'MultiClasses':[],'ConfusionMatrix':[]}

            all_results[name]['AvgClasses'].append(avgclass_result)
            all_results[name]['MultiClasses'].append(multiclass_result)
            all_results[name]['ConfusionMatrix'].append(cm_result)



    for key, _ in all_results.items():
        counts=len(all_results[key]['AvgClasses'])
        if counts!=5:
            print(f'{key}: expect 5 items, but found {counts} items')
        else:
            avg_class = np.array(all_results[key]['AvgClasses'])
            multi_class = np.array(all_results[key]['MultiClasses'])
            confusion_matrix = np.array(all_results[key]['ConfusionMatrix'])

        
            # avg class
            mean_folds_avg_class = np.mean(avg_class,axis=0)
            std_folds_avg_class = np.std(avg_class,axis=0)
            mean_folds_avg_class = np.round(mean_folds_avg_class,2)
            std_folds_avg_class = np.round(std_folds_avg_class,2)
            print(toRed(key))
            print(tplt.format(METRICS[0],METRICS[1],METRICS[2],METRICS[3],METRICS[4]))
            # average over five folds
            print(toCyan('5-fold overall results (Fold x Metric)'))
            print(avg_class)
            print(toCyan('5-fold average results (1 x Metric)'))
            print(mean_folds_avg_class)
            print(std_folds_avg_class)

            # multi class
            print(toCyan('5-fold multi-class results F1 score (Fold x Class)'))
            print(multi_class[:,2,:])
             # multi class
            print(toCyan('5-fold multi-class results Recall score (Fold x Class)'))
            print(multi_class[:,1,:])
            print(toCyan('5-fold mean OVR over multi-class resusts (Metric x Class)'))
            mean_folds_multi_class = np.mean(multi_class,axis=0)
            std_folds_multi_class = np.std(multi_class,axis=0)
            mean_folds_multi_class = np.round(mean_folds_multi_class,2)
            std_folds_multi_class = np.round(std_folds_multi_class,2)
            print(mean_folds_multi_class)
            print(std_folds_multi_class)

            # confusion matrix
            print(toCyan('sum 5-fold confusion matrix'))
            sum_cm = np.sum(confusion_matrix,axis=0)
            print(np.round(sum_cm,1))

            # calculate FPR, TPR, SPECIFITY from confusion matrix
            try:
                if confusion_matrix.shape[1]==0:
                    continue
            except:
                continue
            fpr,tpr,spec=[],[],[]
            for ii in range(confusion_matrix.shape[0]):
                fpr_,tpr_,spec_ = calculate_based_on_cm(confusion_matrix[ii])
                fpr.append(fpr_)
                tpr.append(tpr_)
                spec.append(spec_)
            
            ITEMS={'FPR':fpr,'TPR':tpr,'Spec':spec}

            for key in ITEMS:
                arry = np.array(ITEMS[key])
                mean = np.mean(arry,axis=0)
                std = np.std(arry,axis=0)
                print(toCyan(key))
                print(np.round(mean*100,2))
                print(np.round(std*100,2))



        print(toBlue('----'*6)) 





if __name__ == '__main__':
    main()
