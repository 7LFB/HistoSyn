data_version=0
num_per_category=40
imgs_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/clean_structures'
file_list_folder='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/CVFold/'
caption_list_folder='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/CaptionLists/morphology-enriched'
only_kmeans=0

for fold in 0 1 2 3 4
do
for clusters in 10
do
for caption_template_type in 1
do
CUDA_VISIBLE_DEVICES=0 python FTDiffusers/generate_prompt_text.py \
 --data_version $data_version\
 --fold $fold\
 --num_per_category $num_per_category\
 --imgs_dir $imgs_dir\
 --file_list_folder $file_list_folder\
 --caption_list_folder $caption_list_folder\
 --clusters $clusters\
 --caption_template_type $caption_template_type\
 --only_kmeans $only_kmeans
done
done
done