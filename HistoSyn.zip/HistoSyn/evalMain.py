import os
import cv2
import re
import numpy as np
import random
from skimage.color import rgb2hed
import pandas as pd
from scipy import stats
import glob
import timm
import random
import seaborn as sns

import matplotlib.pyplot as plt
from pdb import set_trace as st
import re
import seaborn as sns
# import multiprocessing as mp
import warnings
warnings.filterwarnings("ignore")
import argparse
import termcolor
from pdb import set_trace as st
from sklearn.metrics import r2_score

# convert to colored strings
def toRed(content): return termcolor.colored(content,"red",attrs=["bold"])
def toGreen(content): return termcolor.colored(content,"green",attrs=["bold"])
def toBlue(content): return termcolor.colored(content,"blue",attrs=["bold"])
def toCyan(content): return termcolor.colored(content,"cyan",attrs=["bold"])
def toYellow(content): return termcolor.colored(content,"yellow",attrs=["bold"])
def toMagenta(content): return termcolor.colored(content,"magenta",attrs=["bold"])




def parse_args():

    parser = argparse.ArgumentParser()
    parser.add_argument('--logDir', type=str, default='/home/comp/chongyin/DataSets/Liver-NASH/SlidingOnWSI')
    parser.add_argument('--method', type=str, default=None)
    parser.add_argument('--proportion', type=str, default='none')
    parser.add_argument('--plot', type=int, default=0)
    parser.add_argument('--cores', type=int, default=1)
    args = parser.parse_args()
    return args

def normalize_columns(arr):
    # Calculate the mean and standard deviation for each column
    means = np.mean(arr, axis=0)
    std_devs = np.std(arr, axis=0)
    
    # Avoid division by zero for columns with a standard deviation of 0
    std_devs[std_devs == 0] = 1
    
    # Normalize each column
    normalized_arr = (arr - means) / std_devs
    return normalized_arr


def main():

    args = parse_args()

    data1=[5.958,2.661,5.420,5.365,4.332,2.939,4.828,4.697,3.610,5.084,3.645,3.166,2.546,4.265,2.24]
    data2=[65.267,32.318,24.289,27.020,41.493,46.981,95.008,30.45,51.64,58.11,35.821,24.512,20.482,16.923,40.013]
    data3=[80.062,80.533,81.219,83.942,84.313,85.716,87.767,83.266,85.108,84.366,84.371,86.664,87.302,89.659,85.588]
    data4=[87.461,86.52,88.793,90.125,89.028,90.752,91.458,89.969,90.596,91.066,88.166,91.536,92.790,92.476,90.125]
    data5=[0.2532,0.3714,0.2744,0.2822,0.3495,0.3529,0.3566,0.3273,0.3578,0.4082,0.3362,0.4333,0.3346,0.3583,0.2707]
    method1 =[[24.863,0.549,16.688,8.752,379.568,0.038,26.413],
                [24.827,3.684,11.854,7.742,166.052,0.028,12.040],
                [26.419,2.491,12.113,8.692,111.965,0.041,8.299],
                [19.749,6.385,15.615,12.488,124.814,0.058,10.028],
                [23.712,11.255,10.334,12.755,224.088,0.038,8.270]]
    method2 =[[18.027,1.427,13.258,5.664,283.205,0.018,7.268],
                [18.561,4.001,11.581,7.055,599.897,0.029,23.930],
                [20.40,9.60,12.38,5.06,140.94,0.02,24.72],
                [13.27,4.52,14.02,11.80,289.10,0.02,28.76],
                [21.22,10.65,10.94,11.12,328.05,0.02,24.80]]
    method3 = [[13.181,2.261,12.923,7.61,204.307,0.023,10.444],
                [1.737,6.028,4.179,4.329,145.583,0.02,9.705],
                [25.251,4.955,10.386,8.395,85.43,0.014,8.94],
                [15.108,4.679,11.801,11.274,69.393,0.03,6.177],
                [11.015,11.058,6.47,8.537,232.279,0.031,10.702]]
    
    raw_data=[method1, method2, method3]
    pearsonr = stats.pearsonr(data1, data3) 
    r_squared = r2_score(data1, data3)
    print(toCyan(f'Pearson Coef: {pearsonr[0]:.4f}, p-value: {pearsonr[1]}'))
    print(toCyan(f'R-squared Coef: {r_squared:.4f}'))

    norm_data2=[]
    for ii in range(3):
        temp=raw_data[ii]
        norm_temp = normalize_columns(np.array(temp))
        norm_data2.extend(np.mean(norm_temp,axis=1))
    # st()
    pearsonr = stats.pearsonr(norm_data2, data3) 
    r_squared = r2_score(data2, data3)
    print(toCyan(f'Pearson Coef: {pearsonr[0]:.4f}, p-value: {pearsonr[1]}'))
    print(toCyan(f'R-squared Coef: {r_squared:.4f}'))

       
  



if __name__ == '__main__':
    main()
