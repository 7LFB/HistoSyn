import argparse
import glob
import os
import cv2
from pdb import set_trace as st
import warnings
warnings.filterwarnings("ignore")
import sys
sys.path.append('/home/comp/chongyin/PyTorch/XDataExpansion/')
from utils.tools import *
from sklearn.mixture import GaussianMixture
import joblib
import time

CAPTION_TEMPLATE='a liver pathology image with {:4s} findings, and spatial arrangement of nuclei is {:.4f}, spatial arrangement of fatty cells is {:.4f}, spatial arrangement of nuclei around fatty cells is {:.4f}, the spatial arrangement of fatty cells around nuclei is {:.4f}, area distribution of fatty cells is {:.4f}, eccentricity distribution of fatty cells is {:.4f}, length distribution of fatty cells is {:.4f}'

# or
CAPTION_TEMPLATE='histology image of {:4s} tissue, spatial attribtue {:.4f}, spatial arrangement of fatty cells is {:.4f}, spatial arrangement of nuclei around fatty cells is {:.4f}, the spatial arrangement of fatty cells around nuclei is {:.4f}, area distribution of fatty cells is {:.4f}, eccentricity distribution of fatty cells is {:.4f}, length distribution of fatty cells is {:.4f}'


def parse_args(input_args=None):
    parser = argparse.ArgumentParser(description="Simple example of a training script.")
    parser.add_argument('--imgs_dir',default='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/clean_structures',type=str)
    parser.add_argument('--samples_dir',default='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/FewSamples',type=str)
    parser.add_argument('--data_version',default=0,type=int)

    # when calculae props
    parser.add_argument('--sample_number',default=10,type=int)
    parser.add_argument('--props_index_str_s',default='0-1-2-3',type=str)
    parser.add_argument('--props_index_str_m',default='0-1-7',type=str)
    parser.add_argument('--kfunc_version', default='S0V0', type=str)
    parser.add_argument('--prior_nuclei', default=1, type=int)
    parser.add_argument('--prior_white', default=1, type=int)
    parser.add_argument('--max', default=1, type=int)
    parser.add_argument('--filter', default=0.1, type=float)
    parser.add_argument('--dilate', default=0, type=int)
    parser.add_argument('--se_kernel', default=11, type=int)
    parser.add_argument('--area_thd', default=0, type=int)
    parser.add_argument('--convex_hull', default=0, type=int)
    parser.add_argument('--clear_border', default=0, type=int)

    # distribution
    parser.add_argument('--est_dist_path',type=str,default='')

    parser.add_argument('--few_reference',type=int,default=0) # use few/all images as reference
    parser.add_argument('--est_dist',type=int,default=0)  
    parser.add_argument('--n_components',type=int,default=7)

    args = parser.parse_args()

    return args


def main():
    
    args = parse_args()

    args.n_components = len(args.props_index_str_s.split('-')) + len(args.props_index_str_m.split('-'))

    if args.data_version==0:
        SUB_TYPES=['others', 'inflammation', 'ballooning', 'steatosis']
        args.samples_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/FewSamples'
        args.imgs_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/clean_structures'
        args.file_list_folder='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/CVFold/'
    elif args.data_version==1:
        pass
    elif args.data_version==2:
        SUB_TYPES=['normal_he_mouse_liver','NAFLD_anomaly_he_mouse_liver']
        args.samples_dir='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/FewSamples'
        args.imgs_dir='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/'
        args.file_list_folder='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/CVFold/'
    elif args.data_version==3: # PCam
        pass

    if args.few_reference:
        data_dir=args.samples_dir     
    else:
        data_dir=args.imgs_dir

    timeRec=AverageMeter()

    # image_path.txt for instance prompt
    # or json file
    for subtype_index, subtype in enumerate(SUB_TYPES):
        class_means=[]
        class_stds=[]
        files = glob.glob(os.path.join(data_dir,subtype,'*.png'))
        for file_index, file in enumerate(files):
            tic = time.time()

            props_dict=generate_prior_and_calculate_props(data_dir,file,args.props_index_str_s,args.props_index_str_m,args)

            single_sample_means=[]
            single_sample_stds=[]

            for index, item in enumerate(props_dict['spatial_values']):
                mean, std = calculate_mean_std_from_list(item,props_dict['spatial_counts'][index])
                single_sample_means.append(mean)
                single_sample_stds.append(std)

            for index, item in enumerate(props_dict['morpho_values']):
                mean, std = calculate_mean_std_from_histogram(item,props_dict['morpho_counts'][index])
                single_sample_means.append(mean)
                single_sample_stds.append(std)


            txt_prompt=CAPTION_TEMPLATE.format(subtype,single_sample_means[0],single_sample_means[1],single_sample_means[2],single_sample_means[3],single_sample_means[4],single_sample_means[5],single_sample_means[6])
            f=open(file.replace('.png','.txt'),'w')
            f.write(txt_prompt)
            f.close()

            class_means.append(single_sample_means)
            class_stds.append(single_sample_stds)

            dur = time.time()-tic
            timeRec.update(dur)
            remain_time = timeRec.average()*(len(files)-file_index)/3600.0

            msg = f'Subtype {subtype_index}/{len(SUB_TYPES)}, Instant {file_index}/{len(files)}, Class_EST {remain_time:.3f}h'
            print('\r',toGreen(msg),end='')

        # mixture gaussian estimation
        if args.est_dist:
            gmm = GaussianMixture(n_components=args.n_components, random_state=0)
            data=np.array(class_means)
            # Fit the model to the data
            gmm.fit(data.reshape(-1, args.n_components))
    
            joblib.dump(gmm, os.path.join(data_dir,f'{subtype}_gmm_model.pkl'))




if __name__ == '__main__':
    main()