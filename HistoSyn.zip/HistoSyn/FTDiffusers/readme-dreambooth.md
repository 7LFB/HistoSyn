# DreamBooth

# STEP-1: data processing for image synthesis using dreambooth
 - **generate_caption_list.py**
    - baseline: ['a liver pathology image with <label> findings']
    - morphology-enriched: ['histology image of <label> tissue, morphology type <index>']
    - histomorphology-focused:
 - **gemerate_prompt_text.py**
# STEP-2: train for dreambooth  
 - **train_dreambooth.py**
    - **args.cmode**: training on mulitclass or single class; switch between mixed and ['otheres', 'inflammation', 'ballooning', 'steatosis']; 
    - **args.decorate_txt_prompts**: whether add rare tokens before class name in txt prompts
# STEP-3: synthetic image using well-trained dreambooth model
 - **inference_dreambooth.py**
    - **args.cmode**: switch between mixed and ['otheres', 'inflammation', 'ballooning', 'steatosis']; testing with model trained on mulitclass or single class
# STEP-4: data processing for downstream tasks 
 - **dividing_train_val_dataset.py** 