from diffusers import StableDiffusionPipeline, DDIMScheduler
import torch
import argparse
import os
from sklearn.mixture import GaussianMixture
import joblib
from pathlib import Path
import json
import glob
from pdb import set_trace as st
import sys
sys.path.append('/home/comp/chongyin/PyTorch/XDataExpansion/')
from utils.util import *


PATTERNS=['others','inflammation','ballooning', 'steatosis']
RARE_TOKENS={'others':'cqcq','inflammation':'kzvx','ballooning':'wqcq','steatosis':'vhxh'}

def parse_args(input_args=None):
    parser = argparse.ArgumentParser(description="Simple example of a training script.")
    parser.add_argument("--output_dir",type=str,default='')
    parser.add_argument("--fold",type=int,default=0)
   
    args = parser.parse_args()
    return args


def main():

    args=parse_args()
    
    # generate train_fold.txt
    files = glob.glob(os.path.join(args.output_dir,'*','*.png'))
    random.shuffle(files)
    with open(os.path.join(args.output_dir,f'train_fold_{args.fold}.txt'),'w') as f:
        for line in files:
            ss = line.split(os.sep)
            index = PATTERNS.index(ss[-2])
            f.write(f'{ss[-2]}/{ss[-1]} {index}\n')
    
    
    


if __name__ == '__main__':
    main()