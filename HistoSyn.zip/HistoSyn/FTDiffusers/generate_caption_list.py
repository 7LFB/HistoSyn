import argparse
import glob
import os
import cv2
from pdb import set_trace as st
import warnings
warnings.filterwarnings("ignore")
import sys
from sklearn.mixture import GaussianMixture
import joblib
import time
import json
import timm
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
sys.path.append('/home/comp/chongyin/lib/HIPT/')
sys.path.append('/home/comp/chongyin/lib/HIPT/HIPT_4K/')
sys.path.append('/home/comp/chongyin/PyTorch/XDataExpansion/')
from utils.dist_distance import *
from utils.util import *
from utils.tools import *


from pdb import set_trace as st

#
# [
#   {
#     "instance_id":None
#     "instance_prompt": args.instance_prompt,
#     "class_prompt": args.class_prompt,
#     "instance_data_dir": args.instance_data_dir,
#     "class_data_dir": args.class_data_dir
#   }
# ]

BASELINE_CAPTION_TEMPLATE=[
    'a liver pathology image with {:4s} findings', 
    'histology image of {:4s} tissue, morphology type {:1d}',
    'a liver pathology image with {:4s} findings, and spatial arrangement of nuclei is {:.4f}, spatial arrangement of fatty cells is {:.4f}, spatial arrangement of nuclei around fatty cells is {:.4f}, the spatial arrangement of fatty cells around nuclei is {:.4f}, area distribution of fatty cells is {:.4f}, eccentricity distribution of fatty cells is {:.4f}, length distribution of fatty cells is {:.4f}']

HISTO_CAPTION_TEMPLATE={
    'others':'histology image of others tissue, with normal nuclei density {:.4f} {:.4f} {:.4f} {:.4f}, indicating  balanced cellular arrangement. Highlight absence of white regions, which no specific alterations like lipid droplets or swelling {:.4f} {:.4f} {:.4f}. These features distinguish others by showing typical tissue appearance without notable white regions',
    'inflammation':'histology image of inflammation tissue, with high nuclei density {:.4f} {:.4f} {:.4f} {:.4f}, indicating crowded cells from an inflammatory response. Highlight absence of white regions, which reflects dense cellular infiltration without lipid droplets {:.4f} {:.4f} {:.4f}. These features distinguish inflammation by showing cellular proliferation, no white spaces',
    'ballooning':'histology image of ballooning tissue, with sparse nuclei density {:.4f} {:.4f} {:.4f} {:.4f}, indicating scattered nuclei due to cell swelling. Highlight presence of white regions, which indicate swollen hepatocytes {:.4f} {:.4f} {:.4f}. These features distinguish ballooning by showing cell damage with clear white areas',
    'steatosis':'histology image of steatosis tissue, with sparse nuclei density {:.4f} {:.4f} {:.4f} {:.4f}, indicating less crowed cells due to lipid accumulation. Highlight presence of white regions, which represent lipid droplets in hepatocytes {:.4f} {:.4f} {:.4f}. These features distinguish steatosis by showing fat accumulation with swollen, pale cells'}

PLAIN_HISTO_CAPTION_TEMPLATE={
    'others':'histology image of others tissue, with normal nuclei density, indicating  balanced cellular arrangement. Highlight absence of white regions, which no specific alterations like lipid droplets or swelling. These features distinguish others by showing typical tissue appearance without notable white regions',
    'inflammation':'histology image of inflammation tissue, with high nuclei density, indicating crowded cells from an inflammatory response. Highlight absence of white regions, which reflects dense cellular infiltration without lipid droplets. These features distinguish inflammation by showing cellular proliferation, no white spaces',
    'ballooning':'histology image of ballooning tissue, with sparse nuclei density, indicating scattered nuclei due to cell swelling. Highlight presence of white regions, which indicate swollen hepatocytes. These features distinguish ballooning by showing cell damage with clear white areas',
    'steatosis':'histology image of steatosis tissue, with sparse nuclei density, indicating less crowed cells due to lipid accumulation. Highlight presence of white regions, which represent lipid droplets in hepatocytes. These features distinguish steatosis by showing fat accumulation with swollen, pale cells'}

MEAN=np.array([0.485, 0.456, 0.406])
STD=np.array([0.229, 0.224, 0.225])

def opencv2pil(img):
    rgb_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    # Create a PIL image from the OpenCV image
    pil_img = Image.fromarray(rgb_img) 

    return pil_img

def cv2_imread_resize(path,mode,resize=(224,224)):
    x=cv2.imread(path,mode)
    x=cv2.resize(x, (resize[0], resize[1]))
    return x

def _read_image(path, resize=(224, 224), pil_format=0):
    img=cv2_imread_resize(path,1,resize=resize)
    if pil_format: 
        img = opencv2pil(img) 
    return img

def k_means(img_dir,file_list,myProjector,base_transforms,clusters=33,save_fig_path=None):
    featsX=[]
    for file_ in file_list:
        file=file_.split(' ')[0]
        img = Image.open(os.path.join(img_dir,file))
        imgTensor=base_transforms(img)
        feat=myProjector.forward_features(imgTensor.unsqueeze(0).cuda()) # 1 x (1+16x16) x 384 or # 1x512xhxw
        feat = feat[:,:1,:]
        feat = torch.squeeze(feat).detach().cpu().numpy()
        featsX.append(feat)
    # dealing with high-dimentional feature
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(featsX)
    kmeans = KMeans(n_clusters=clusters)
    kmeans.fit(X_pca)
    y_kmeans = kmeans.predict(X_pca)    

    # plot figure
    plt.figure(figsize=(8, 6))
    plt.scatter(X_pca[:, 0], X_pca[:, 1], c=y_kmeans, s=50, cmap='viridis')

    centers = kmeans.cluster_centers_
    plt.scatter(centers[:, 0], centers[:, 1], c='red', s=200, alpha=0.5)
    plt.title('KMeans Clustering with PCA')
    plt.xlabel('Principal Component 1')
    plt.ylabel('Principal Component 2')
    if not os.path.exists(os.path.dirname(save_fig_path)):
        os.makedirs(os.path.dirname(save_fig_path))
    plt.savefig(save_fig_path)

    return y_kmeans

    


def parse_args(input_args=None):
    parser = argparse.ArgumentParser(description="Simple example of a training script.")
    parser.add_argument('--imgs_dir',default=None,type=str)
    parser.add_argument('--file_list_folder',default=None,type=str)
    parser.add_argument('--caption_list_folder',default=None,type=str)
    parser.add_argument('--samples_dir',default=None,type=str)
    parser.add_argument('--data_version',default=0,type=int)
    parser.add_argument('--cmode',default='mixed',type=str)
    parser.add_argument('--fold',default=0,type=int)
    parser.add_argument('--num_per_category',default=42,type=int)

    # Kmeans clustering
    parser.add_argument('--proj',default='lunit-dino',type=str)
    parser.add_argument('--clusters',default=21,type=int)

    parser.add_argument('--caption_template_type',default=0,type=int)

    parser.add_argument('--only_kmeans',default=0,type=int)


    # when calculae props
    parser.add_argument('--sample_number',default=10,type=int)
    parser.add_argument('--props_index_str_s',default='0-1-2-3',type=str)
    parser.add_argument('--props_index_str_m',default='0-1-7',type=str)
    parser.add_argument('--kfunc_version', default='S0V0', type=str)
    parser.add_argument('--prior_nuclei', default=1, type=int)
    parser.add_argument('--prior_white', default=1, type=int)
    parser.add_argument('--nuclei_seg_model', default='pannuke', type=str)
    parser.add_argument('--max', default=1, type=int)
    parser.add_argument('--filter', default=0.1, type=float)
    parser.add_argument('--dilate', default=0, type=int)
    parser.add_argument('--se_kernel', default=11, type=int)
    parser.add_argument('--area_thd', default=0, type=int)
    parser.add_argument('--convex_hull', default=0, type=int)
    parser.add_argument('--clear_border', default=0, type=int)
    parser.add_argument('--suffix', default='', type=str)

    

    args = parser.parse_args()

    return args


def main():
    
    args = parse_args()

    if args.data_version==0:
        SUB_TYPES=['others', 'inflammation', 'ballooning', 'steatosis']
        if args.imgs_dir==None: args.imgs_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/clean_structures'
        if args.file_list_folder==None: args.file_list_folder='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/CVFold/'
        if args.caption_list_folder==None: args.caption_list_folder='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/CaptionLists'
    elif args.data_version==1:
        pass
    elif args.data_version==2:
        SUB_TYPES=['normal_he_mouse_liver','NAFLD_anomaly_he_mouse_liver']
        if args.imgs_dir==None: args.imgs_dir='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/'
        if args.file_list_folder==None: args.file_list_folder='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/CVFold/'
        if args.caption_list_folder==None: args.caption_list_folder='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/CaptionLists'
    elif args.data_version==3: # PCam
        pass

    # feature embedding setting
    if args.proj=='lunit-dino':
        myProjector=timm.create_model(model_name="hf-hub:1aurent/vit_small_patch16_224.lunit_dino",pretrained=True,features_only=False,num_classes=0,global_pool='').cuda()
        # get model specific transforms (normalization, resize)
        data_config = timm.data.resolve_model_data_config(myProjector)
        base_transforms = timm.data.create_transform(**data_config, is_training=False)

    
    myProjector.eval() # chong: important!
    

    _x_train = [os.path.join(args.file_list_folder, 'train_fold_'+str(args.fold)+'.txt')]

    XY = readlines_from_txt(_x_train)
    XX=balance_data(XY,num_per_category=args.num_per_category)

    if args.caption_template_type==1:
        print(toBlue('Perform KMeans clustering ...'))
        save_fig_path=os.path.join(args.caption_list_folder,f'balance_{args.num_per_category}_cluster_{args.clusters}_fold_{args.fold}.png')
        y_kmeans=k_means(args.imgs_dir,XX,myProjector=myProjector,base_transforms=base_transforms,clusters=args.clusters,save_fig_path=save_fig_path)

        if args.only_kmeans:
            sys.exit()

    dict_list=[]
    for index, item in enumerate(XX):
        if args.caption_template_type==0: # baseline
            instance_prompt=BASELINE_CAPTION_TEMPLATE[args.caption_template_type].format(item.split('/')[0])
        elif args.caption_template_type==1: # morpho-enriched (DINO clustering)
            instance_prompt=BASELINE_CAPTION_TEMPLATE[args.caption_template_type].format(item.split('/')[0],y_kmeans[index])
        elif args.caption_template_type==2: # histomorphology-focused
            props_dict=generate_prior_and_calculate_props(args.imgs_dir,item,args.props_index_str_s,args.props_index_str_m,args)

            single_sample_means=[]
            single_sample_stds=[]

            for index, value in enumerate(props_dict['spatial_values']):
                mean, std = calculate_mean_std_from_list(value,props_dict['spatial_counts'][index])
                single_sample_means.append(mean)
                single_sample_stds.append(std)

            for index, value in enumerate(props_dict['morpho_values']):
                mean, std = calculate_mean_std_from_histogram(value,props_dict['morpho_counts'][index])
                single_sample_means.append(mean)
                single_sample_stds.append(std)


            instance_prompt=HISTO_CAPTION_TEMPLATE[item.split('/')[0]].format(single_sample_means[0],single_sample_means[1],single_sample_means[2],single_sample_means[3],single_sample_means[4],single_sample_means[5],single_sample_means[6])

        elif args.caption_template_type==3: # histomorphology-focused (plain)
            instance_prompt=PLAIN_HISTO_CAPTION_TEMPLATE[item.split('/')[0]]

        
        temp={
                "instance_id":item,
                "instance_prompt": instance_prompt,
                "class_prompt": None,
                "instance_data_dir": args.imgs_dir,
                "class_data_dir": None
            }
        dict_list.append(temp)

    # reanme the file name manually
    # original 
    # new template based on reviewer's suggestion
    # using new nuclei segmentation model (cellpose)
    save_file_name=f'train_fold_{args.fold}_balance_{args.num_per_category}_cellPoseSeg.json'
    if not os.path.exists(args.caption_list_folder):
        os.makedirs(args.caption_list_folder)
    with open(os.path.join(args.caption_list_folder,save_file_name),'w') as file:
        json.dump(dict_list,file,indent=4)


    # # write into txt
    # with open(os.path.join(args.caption_list_folder,save_file_name),'r') as file:
    #     dict_list=json.load(file)
    # random.seed(1024)
    # random.shuffle(dict_list)
    # with open(os.path.join(args.caption_list_folder,f'train_fold_{args.fold}.txt'),'w') as f:
    #     for item in dict_list:
    #         idstr = item['instance_id']
    #         index = SUB_TYPES.index(idstr.split('/')[0])
    #         f.write(f'{idstr} {index}\n')
    
    

    


    

    


    




if __name__ == '__main__':
    main()