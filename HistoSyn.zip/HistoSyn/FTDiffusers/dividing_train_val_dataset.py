
import glob
import os
import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit
import numpy as np 
import argparse

from pdb import set_trace as st
def train_val_test_split(X,Y, output_dir=None, n_splits=5, val_size=0.1, test_size=0.2, random_state=0):
    ss_test = StratifiedShuffleSplit(
        n_splits=n_splits, test_size=test_size, random_state=random_state)

    ss_train_val = StratifiedShuffleSplit(
        n_splits=1, test_size=val_size/(1-test_size), random_state=random_state)

    fold = 0
    for train_val_index, test_index in ss_test.split(X, Y):
        ftest = open(os.path.join(
            output_dir, 'test_fold_'+str(fold)+'.txt'), 'w')
        for item in test_index:
            ftest.write(X[item]+'\n')
        
        tempX=[]
        tempY=[]
        for item in train_val_index:
            tempX.append(X[item])
            tempY.append(Y[item])

        
        for train_index, val_index in ss_train_val.split(tempX,tempY):
            ftrain = open(os.path.join(
               output_dir, 'train_fold_'+str(fold)+'.txt'), 'w')
            for item in train_index:
                ftrain.write(tempX[item]+'\n')
            
            fval = open(os.path.join(
               output_dir, 'val_fold_'+str(fold)+'.txt'), 'w')
            for item in val_index:
                fval.write(tempX[item]+'\n')

        ftrain.close()
        fval.close()
        ftest.close()
        fold += 1


def train_test_split(X,Y,output_dir=None,n_splits=5,test_size=0.2,random_state=0):
    

    ss=StratifiedShuffleSplit(n_splits=n_splits, test_size=test_size, random_state=random_state)

    fold=0
    for train_index, test_index in ss.split(X,Y):

        ftrain=open(os.path.join(output_dir,'train_fold_'+str(fold)+'_syn.txt'),'w')
        ftest = open(os.path.join(output_dir, 'val_fold_'+str(fold)+'_syn.txt'), 'w')
        
        for item in train_index:
            ftrain.write(f'{X[item]} {Y[item]}\n')
        for item in test_index:
            ftest.write(f'{X[item]} {Y[item]}\n')
        ftrain.close()
        ftest.close()
        fold+=1


def parse_args():
    parser = argparse.ArgumentParser(description='Train network')

    parser.add_argument('--val_size', default=0.2, type=int)
    parser.add_argument('--test_size', default=0.2, type=int)
    parser.add_argument('--data_version', default=0, type=int)
    parser.add_argument('--file_list_folder',default=None,type=str)
    

    args = parser.parse_args()

    return args

def main():

    args=parse_args()

    if args.data_version==0:
        args.data_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/SyntheticSamples/stable-diffusion-v1-5/'
        args.file_list_folder='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/CVFold/'
        SUB_TYPES=['others','inflammation','ballooning', 'steatosis']
    elif args.data_version==1:
        pass
    elif args.data_version==2:
        args.data_dir='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/SyntheticSamples/stable-diffusion-v1-5/'
        args.file_list_folder='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/CVFold/'
        SUB_TYPES=['normal_he_mouse_liver','NAFLD_anomaly_he_mouse_liver']
    elif args.data_version==3: # PCam
        pass

    X = []
    Y = []

    for index, subfolder in enumerate(SUB_TYPES):
        files = glob.glob(os.path.join(args.data_dir,subfolder,'*.png'))
        for file in files:
            X.append(f'{subfolder}/{os.path.basename(file)}')
            Y.append(index)

    train_test_split(X,Y,output_dir=args.file_list_folder,n_splits=5,test_size=args.val_size)
    # train_val_test_split(X,Y, data='steatosis', n_splits=5, val_size=0.1,test_size=0.2)


if __name__ == '__main__':
    main()