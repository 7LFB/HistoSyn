
real_data_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/clean_structures'
syn_data_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/SyntheticSamples/stable-diffusion-v1-5'
caption_list_dir='/home/comp/chongyin/DataSets/LiverNASTiles-20230727/CaptionLists'
model_name='ours-balance-280-v1-RareToken0'
caption_list_subfolder='histomorphology-focused-v1'

calc_umap=0
calc_fid=0
calc_distribution_distance=1

for num_per_category in 280
do
for data_version in 0
do
for fold in 0 1 2 3 4
do
for cmode in 'mixed'
do
CUDA_VISIBLE_DEVICES=0 python QualityEvaluation/evaluate_real_synthesis_data.py \
 --cmode $cmode\
 --data_version $data_version\
 --syn_data_dir "${syn_data_dir}/${model_name}-fold${fold}"\
 --real_data_dir $real_data_dir\
 --caption_list_dir "${caption_list_dir}/${caption_list_subfolder}/${num_per_category}"\
 --calc_umap $calc_umap\
 --calc_fid $calc_fid\
 --calc_distribution_distance $calc_distribution_distance\
 --model_name "${model_name}-fold${fold}"\
 --fold $fold
done
done
done
done