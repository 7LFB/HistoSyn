import argparse
import os
import pprint
import shutil
import sys

import logging
import time
import timeit
from pathlib import Path
import glob
import pandas as pd
import importlib

import re

import numpy as np
import json

import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
import torch.optim
from tensorboardX import SummaryWriter
import warnings
warnings.filterwarnings("ignore")


from torch.optim.lr_scheduler import MultiStepLR, LambdaLR, CosineAnnealingLR, StepLR

from core.function import train, validate, test
from utils.params import *
from utils.util import *
from utils.spatial_statistics import *
from dataset.myDataset import myTileDataset

from torchsampler import ImbalancedDatasetSampler

from pdb import set_trace as st

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
# 设置随机数种子

def main():
    args = parse_args()

    if args.data_version==0:
        if args.real_data_dir is None:
            args.real_data_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/clean_structures/'
        if args.test_file_list_folder is None:
            args.test_file_list_folder='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/CVFold/'
        if args.syn_data_dir is None:
            args.syn_data_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/SyntheticSamples/stable-diffusion-v1-5/'
        if args.syn_file_list_folder is None:
            args.syn_file_list_folder=os.path.join(args.syn_data_dir,'CVFold')
        
    elif args.data_version==1:
        pass
    elif args.data_version==2:
        if args.real_data_dir is None:
            args.real_data_dir='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/'
        if args.test_file_list_folder is None:
            args.test_file_list_folder='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/CVFold/'
        if args.syn_data_dir is None:
            args.syn_data_dir='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/SyntheticSamples/stable-diffusion-v1-5/'
        if args.syn_file_list_folder is None:
            args.syn_file_list_folder=os.path.join(args.syn_data_dir,'CVFold')
        
    elif args.data_version==3:
        pass

    # 5-fold cross validation
    args.model_name= f'F{args.fold}-{args.model_name}-mv{args.mversion}-seed{args.seed}'
    args.snapshot_dir = args.snapshot_dir.replace(
        'XDataExpand/', 'XDataExpand/' + args.model_name + '-')


    if not os.path.exists(args.snapshot_dir):
        os.makedirs(args.snapshot_dir)
    print(toMagenta(args.snapshot_dir))

    # saving args into txt file for recording
    with open(os.path.join(args.snapshot_dir,'commandline_args.json'), 'wt') as f:
        json.dump(vars(args), f, indent=4)


    writer_dict = {
        'writer': SummaryWriter(args.snapshot_dir),
        'train_global_steps': 0,
        'valid_global_steps': 0,
        'test_global_steps':0
    }

    # cudnn related setting
    gpus = [ii for ii in range(args.num_gpus)]

    setup_seed(args.seed)

    # using real or synthetic images, or mixed together for model training
    # pre-determine the ratio=synthetic/real 
    # real_syn_mode= 0 real data only, 1 syn data only, 2 mixed together
    if args.real_syn_mode==0:
        _x_train = [os.path.join(args.real_file_list_folder, 'train_fold_'+str(args.fold)+'.txt')]
        x_train = readlines_from_txt(_x_train)
        if args.real_ratio<1.0: x_train=balance_sampler(x_train,args.real_ratio)
    elif args.real_syn_mode==1:
        _x_train = [os.path.join(args.syn_file_list_folder, 'train_fold_'+str(args.fold)+'.txt')]
        x_train = readlines_from_txt(_x_train)
        if args.syn_ratio<1.0: x_train=balance_sampler(x_train,args.real_ratio)
    elif args.real_syn_mode==2:
        _x_train_real = [os.path.join(args.real_file_list_folder, 'train_fold_'+str(args.fold)+'.txt')]
        _x_train_syn = [os.path.join(args.syn_file_list_folder, 'train_fold_'+str(args.fold)+'.txt')]
        x_train_real =readlines_from_txt(_x_train_real)
        x_train_syn =readlines_from_txt(_x_train_syn)
        if args.real_ratio<1.0: x_train_real=balance_sampler(x_train_real,args.real_ratio)
        x_train_syn = balance_sampler(x_train_syn,args.syn_ratio)
        x_train = x_train_real + x_train_syn
    
    # always val and test on real images
    _x_val = [os.path.join(args.test_file_list_folder, 'val_fold_'+str(args.fold)+'.txt')]
    _x_test = [os.path.join(args.test_file_list_folder, 'test_fold_'+str(args.fold)+'.txt')]
    x_val =readlines_from_txt(_x_val)
    x_test =readlines_from_txt(_x_test)

    x_test_tileNames=[x.split(' ')[0] for x in x_test]
    
    train_dataset=myTileDataset(x_train,args.real_data_dir,synDataDir=args.syn_data_dir,h=args.img_h,w=args.img_w,is_training=True,augment=args.augment,auto_augment=args.auto_augment,args=args)
    # validate and test on real dataset
    val_dataset=myTileDataset(x_val,args.real_data_dir,synDataDir=None,h=args.img_h,w=args.img_w,args=args)
    test_dataset=myTileDataset(x_test,args.real_data_dir,synDataDir=None,h=args.img_h,w=args.img_w,args=args)

    trainloader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        prefetch_factor=2,
        shuffle=False,
        num_workers=args.workers,
        pin_memory=True,
        drop_last=True,
        sampler=ImbalancedDatasetSampler(train_dataset))

    valloader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=args.batch_size_for_test,
        shuffle=False,
        num_workers=args.workers,
        pin_memory=True)

    testloader = torch.utils.data.DataLoader(
        test_dataset,
        batch_size=args.batch_size_for_test,
        shuffle=False,
        num_workers=args.workers,
        pin_memory=True)


    # # model configuration
    module=importlib.import_module(f'models.model_v{args.mversion}')
    Biopsy = getattr(module, 'Biopsy')
    model=Biopsy(args)
    print(toRed(f'version-{args.mversion}'))


    # freeze fundation model
    if args.freeze_pattern:
        patterns=args.freeze_pattern.split('-')
        print(toRed(f'Freeze {args.freeze_pattern} \n'))
        for name, param in model.named_parameters():
            for pattern in patterns:
                if re.search(pattern, name):
                    param.requires_grad = False
                    print(name)
                    break
    
    # optimizer
    optimizer = torch.optim.SGD(filter(lambda p: p.requires_grad, model.parameters()),
                                lr=args.lr,
                                momentum=args.momentum,
                                weight_decay=args.weight_decay,
                                )
    lr_scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=30, gamma=0.1)

    model = nn.DataParallel(model, device_ids=gpus).cuda()


    best_val_f1 = 0
    best_val_msg=''
    best_test_msg=''
    history_test_f1=0
    best_test_con_mat=0
    best_test_ovr_mat=0
  

    ## load the ckpt dict
    if args.ckpt_path:
        model_state_file = args.ckpt_path
        pretrained_dict = torch.load(model_state_file)
        model_dict = model.state_dict()
        pretrained_dict = {k: v for k, v in pretrained_dict.items()
                           if k in model_dict.keys()}
        for k, _ in pretrained_dict.items():
            print(toCyan('=> loading {} from pretrained model'.format(k)))
        model_dict.update(pretrained_dict)
        model.load_state_dict(model_dict)


    # write final results into specific record.txt
    subf = open(os.path.join(args.snapshot_dir, 'record.txt'),'a+')

    for epoch in range(args.start_epoch, args.num_epochs):
        train(model, trainloader, optimizer, writer_dict, epoch, args)

        lr_scheduler.step()

        print('\t')
        print('---model_name---')
        print(args.model_name)

        val_accuracy, val_specificity, val_recall, val_f1, val_auc, val_con_mat, val_ovr_mat = validate(model, valloader, writer_dict, args)
        val_msg = f'Val: {args.model_name}: Epoch:{epoch}, Accuracy:{val_accuracy*100:.3f}, Specificity:{val_specificity*100:.3f}, Recall:{val_recall*100:.3f}, F1:{val_f1*100:.3f}, AUC:{val_auc*100:.3f}'
        print(val_msg+'\n')
        print('Val multi-class one-vs-rest result\t')
        print(str(val_ovr_mat)+'\n')

        gts, predicts, probs, accuracy, specificity, recall, f1, auc, con_mat, ovr_mat = test(model, testloader, writer_dict, args)

        if f1>history_test_f1:
            history_test_f1=f1

        test_result = np.concatenate([np.expand_dims(gts,-1),np.expand_dims(predicts,-1),probs],axis=-1)

        test_result_excel={'tileNames':x_test_tileNames,'gts':gts.tolist(),'predicts':predicts.tolist()}

        test_msg = f'{args.model_name}: Epoch:{epoch}, Accuracy:{accuracy*100:.3f}, Specificity:{specificity*100:.3f}, Recall:{recall*100:.3f}, F1:{f1*100:.3f}, AUC:{auc*100:.3f}, HistoryBestF1:{history_test_f1*100:.3f}'


        if val_f1 >= best_val_f1:
            best_val_f1 = val_f1
            best_test_msg=test_msg
            best_test_con_mat=con_mat
            best_test_ovr_mat=ovr_mat
            print(toMagenta('Best is: '+best_test_msg))
            print('Test multi-class one-vs-rest result\t')
            print(str(ovr_mat)+'\n')
            print('Test Confusion Matrix\t')
            print(str(con_mat)+'\n')
            torch.save(model.module.state_dict(),
                       os.path.join(args.snapshot_dir, 'best.pth'))
            
            np.save(os.path.join(args.snapshot_dir, f'T{args.fold}.npy'),test_result)
            df = pd.DataFrame.from_dict(test_result_excel)
            df.to_excel(os.path.join(args.snapshot_dir, f'T{args.fold}.xlsx'))
            
            
        subf.write('\t')
        subf.write('---'*5 + '\n')
        subf.write('validation results ...\n')
        subf.write(val_msg+'\n')
        subf.write('test results ...\n')
        subf.write(test_msg+'\n')
        subf.write('one-vs-rest: (specificity,recall,f1,auc)x(none,inflammation,ballooning,steatosis)\n')
        subf.write(str(ovr_mat)+'\n')
        subf.write('Confusion Matrix\n')
        subf.write(str(con_mat)+'\n')
        subf.write('Best test results ...\n')
        subf.write(best_test_msg+'\n')



    f = open('./log/' + args.logdir_name+'.txt', 'a+')
    f.write('\t')
    f.write('---'*5 + '\n')
    f.write(args.snapshot_dir+'\n')
    f.write(best_test_msg+'\n')
    f.write('(specificity,recall,f1,auc)x(none,inflammation,ballooning,steatosis)\n')
    f.write(str(best_test_ovr_mat)+'\n')
    f.write('Confusion Matrix\n')
    f.write(str(best_test_con_mat)+'\n')
    f.close()


   

if __name__ == '__main__':
    main()
