
proportion='none'
logDir='/home/comp/chongyin/DataSets/Liver-NASH/SlidingOnWSI/SynthesisMethods'

for method in 'baseline-balance-28-RareToken0-realSynMode0' 'baseline-balance-28-RareToken0-realSynMode2'  'morph-enriched-balance-28-RareToken0-realSynMode2' 'ours-balance-v2-28-RareToken0-realSynMode2'
do
CUDA_VISIBLE_DEVICES=1 python analysis_slide_level_results.py\
 --method $method\
 --proportion $proportion\
 --logDir $logDir
done