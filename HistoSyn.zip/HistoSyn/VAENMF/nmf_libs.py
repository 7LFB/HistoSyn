import torch
import torch.nn as nn
import math, time
from torch.autograd import Function, Variable
import torch.nn.functional as F
from contextlib import contextmanager
from einops import repeat, rearrange
import numpy as np
import torch_scatter
EPSILON = 1e-7
import timm
import os

from pdb import set_trace as st

#####################################################################
# implementation of differential topK #

@contextmanager
def null_context():
    yield

def exists(val):
    return val is not None

def default(val, d):
    return val if exists(val) else d

class PerturbedTopK(nn.Module):
    def __init__(self, k: int, num_samples: int = 1000, sigma: float = 0.05):
        super(PerturbedTopK, self).__init__()
        self.num_samples = num_samples
        self.sigma = sigma
        self.k = k

    def __call__(self, x): # input score with dimension (batch_size, dim) ?
        return PerturbedTopKFunction.apply(x, self.k, self.num_samples, self.sigma)


class PerturbedTopKFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, k: int, num_samples: int = 1000, sigma: float = 0.05):
        b, d = x.shape
        # for Gaussian: noise and gradient are the same.
        noise = torch.normal(mean=0.0, std=1.0, size=(b, num_samples, d)).to(x.device)

        perturbed_x = x[:, None, :] + noise * sigma # b, nS, d
        topk_results = torch.topk(perturbed_x, k=k, dim=-1, sorted=True) # chong:2022-12-03 sorted for calculate accumulated score, we set sorted=True here.
        indices = topk_results.indices # b, nS, k
        indices = torch.sort(indices, dim=-1).values # b, nS, k

        # b, nS, k, d
        perturbed_output = torch.nn.functional.one_hot(indices, num_classes=d).float()
        indicators = perturbed_output.mean(dim=1) # b, k, d

        # constants for backward
        ctx.k = k
        ctx.num_samples = num_samples
        ctx.sigma = sigma

        # tensors for backward
        ctx.perturbed_output = perturbed_output
        ctx.noise = noise

        return indicators

    @staticmethod
    def backward(ctx, grad_output):
        if grad_output is None:
            return tuple([None] * 5)

        noise_gradient = ctx.noise
        expected_gradient = (
        torch.einsum("bnkd,bnd->bkd", ctx.perturbed_output, noise_gradient)
        / ctx.num_samples
        / ctx.sigma
        )
        grad_input = torch.einsum("bkd,bkd->bd", grad_output, expected_gradient)
        return (grad_input,) + tuple([None] * 5)



#####################################################################
# implementation of NMF #
class NMF(nn.Module):
    def __init__(
        self,
        dim,
        n,
        ratio = 8,
        K = 6,
        eps = 2e-8
    ):
        super().__init__()
        r = int(dim // ratio)

        D = torch.zeros(dim, r).uniform_(0, 1)
        C = torch.zeros(r, n).uniform_(0, 1)

        self.K = K
        self.D = nn.Parameter(D)
        self.C = nn.Parameter(C)

        self.eps = eps

    def _re_init(self):
        with torch.no_grad():
            nn.init.uniform_(self.D, 0, 1) 
            nn.init.uniform_(self.C, 0, 1) 

    def forward(self, x):
        b, D, C, eps = x.shape[0], self.D, self.C, self.eps

        # x is made non-negative with relu as proposed in paper
        x = F.relu(x)

        D = repeat(D, 'd r -> b d r', b = b)
        C = repeat(C, 'r n -> b r n', b = b)

        # transpose
        t = lambda tensor: rearrange(tensor, 'b i j -> b j i')

        for k in reversed(range(self.K)):
            # only calculate gradients on the last step, per propose 'One-step Gradient'
            context = null_context if k == 0 else torch.no_grad
            with context():
                C_new = C * ((t(D) @ x) / ((t(D) @ D @ C) + eps))
                D_new = D * ((x @ t(C)) / ((D @ C @ t(C)) + eps))
                C, D = C_new, D_new

        return D @ C , D, C


# implementation of NMF #
class MultiHeadNMF(nn.Module):
    def __init__(
        self,
        dim,
        n,
        head =1,
        ratio = 8,
        K=6,
        eps = 2e-8
    ):
        super().__init__()

        self.head=head
        local_dim = int(dim/head)
        self.local_NMFs=nn.ModuleList(NMF(dim=local_dim, n= n, ratio=ratio, K=K) for ii in range(self.head))
        

    def forward(self, x):
        # x: -1 X dim X n
        x_tuple = torch.chunk(x,self.head,dim=1)
        local_Ys=[]
        local_Ms=[]
        local_Ns=[]
        for ii in range(self.head):
            tempY,tempM,tempN = self.local_NMFs[ii](x_tuple[ii])
            local_Ys.append(tempY)
            local_Ms.append(tempM)
            local_Ns.append(tempN)

        Y = torch.cat(local_Ys,dim=1)
        M = torch.cat(local_Ms,dim=1)
        N = torch.cat(local_Ns,dim=1)

        return Y, M, N


# implementation of NMF + two conv layer to adjust hidden layer #
class MultiHeadNMFv2(nn.Module):
    def __init__(
        self,
        dim,
        hid,
        n,
        head =1,
        ratio = 8,
        K=6,
        eps = 2e-8
    ):
        super().__init__()

        self.lower_conv = nn.Conv1d(dim,hid,1,bias=False)
        self.upper_conv = nn.Conv1d(hid,dim,1,bias=False)
        self.head=head
        local_dim = int(hid/head)
        self.local_NMFs=nn.ModuleList(NMF(dim=local_dim, n= n, ratio=ratio, K=K) for ii in range(self.head))
        

    def forward(self, x):
        # x: -1 X dim X n
        x = self.lower_conv(x)
        x_tuple = torch.chunk(x,self.head,dim=1)
        local_Ys=[]
        local_Ms=[]
        local_Ns=[]
        for ii in range(self.head):
            tempY,tempM,tempN = self.local_NMFs[ii](x_tuple[ii])
            local_Ys.append(tempY)
            local_Ms.append(tempM)
            local_Ns.append(tempN)

        Y = torch.cat(local_Ys,dim=1)
        M = torch.cat(local_Ms,dim=1)
        N = torch.cat(local_Ns,dim=1)
        Y = self.upper_conv(Y)

        return Y, M, N



       



