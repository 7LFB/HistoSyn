import torch
import torchnmf
from torchnmf.nmf import NMF
import argparse
import os
import numpy as np
import glob
import h5py
import random

from pdb import set_trace as st


def parse_args():
    parser = argparse.ArgumentParser(description='Train network')

    # dataset
    parser.add_argument('--root_img_dir',default='/home/comp/chongyin/DataSets/PCam',type=str)
    parser.add_argument('--prefix_name',default='camelyonpatch_level_2_split',type=str)
    parser.add_argument('--mode',default='train',type=str)
    parser.add_argument('--ratio',default=0.01, type=float)

    parser.add_argument('--output_dir',default='/home/comp/chongyin/checkpoints/VAENMF', type=str)

    args = parser.parse_args()

    return args


def sampling_data(x,y,ratio):
    num=x.shape[0]
    index_list = list(range(num))
    random.shuffle(index_list)
    num_elements_to_fetch = max(1, int(num*ratio))
    # Fetch the first 10% of elements from the shuffled list
    selected_elements = index_list[:num_elements_to_fetch]
    selected_elements.sort()

    selected_x = x[selected_elements]
    selected_y = y[selected_elements]

    return selected_x, selected_y


def train(args):
    train_dataset_x=h5py.File(os.path.join(args.root_img_dir,f'{args.prefix_name}_{args.mode}_x.h5'))['x']
    train_dataset_y=h5py.File(os.path.join(args.root_img_dir,f'{args.prefix_name}_{args.mode}_y.h5'))['y']
    
    # N x 96 x 96 x 3
    train_sub_x_, train_sub_y = sampling_data(train_dataset_x,train_dataset_y,args.ratio)

    train_sub_x = np.transpose(train_sub_x_,(0,3,1,2))

    V = torch.from_numpy(train_sub_x).cuda().float()
    model = torchnmf.nmf.NMF2D(V.shape,rank=10,kernel_size=3).cuda()

    # training
    model.fit(V)

    st()

    aa=0



def test():
    pass


def main():
    args = parse_args()
    train(args)

if __name__ == '__main__':
    main()