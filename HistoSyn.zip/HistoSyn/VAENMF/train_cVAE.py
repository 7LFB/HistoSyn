import torch
import torch.utils.data
from torch import nn, optim
from torch.nn import functional as F
from torchvision import datasets, transforms
from torchvision.utils import save_image
import argparse
import os
import numpy as np
import glob
import h5py
import random

from pdb import set_trace as st


def parse_args():
    parser = argparse.ArgumentParser(description='Train network')

    # dataset
    parser.add_argument('--root_img_dir',default='/home/comp/chongyin/DataSets/PCam',type=str)
    parser.add_argument('--prefix_name',default='camelyonpatch_level_2_split',type=str)
    parser.add_argument('--mode',default='train',type=str)
    parser.add_argument('--ratio',default=0.01, type=float)

    parser.add_argument('--output_dir',default='/home/comp/chongyin/checkpoints/VAENMF', type=str)

    parser.add_argument('--model_name',default='cVAE', type=str)

    # 
    parser.add_argument('--img_h', default=28, type=int)
    parser.add_argument('--img_w', default=28, type=int)
    parser.add_argument('--img_c', default=1, type=int)
    parser.add_argument('--num_class', default=10, type=int)
    parser.add_argument('--batch_size', default=64, type=int)
    parser.add_argument('--latent_dim', default=20, type=int)
    parser.add_argument('--epochs', default=10, type=int)
    parser.add_argument('--lr', default=1e-3, type=float)
    parser.add_argument('--num_workers', default=1, type=int)
    parser.add_argument('--pin_memory', default=True, type=int)

    args = parser.parse_args()

    return args



def one_hot(labels, class_size):
    targets = torch.zeros(labels.size(0), class_size)
    for i, label in enumerate(labels):
        targets[i, label] = 1
    return targets.cuda()


class cVAE(nn.Module):
    def __init__(self, feature_size, latent_size, class_size):
        super(cVAE, self).__init__()
        self.feature_size = feature_size
        self.class_size = class_size

        # encode
        self.fc1  = nn.Linear(feature_size + class_size, 400)
        self.fc21 = nn.Linear(400, latent_size)
        self.fc22 = nn.Linear(400, latent_size)

        # decode
        self.fc3 = nn.Linear(latent_size + class_size, 400)
        self.fc4 = nn.Linear(400, feature_size)

        self.elu = nn.ELU()
        self.sigmoid = nn.Sigmoid()

    def encode(self, x, c): # Q(z|x, c)
        '''
        x: (bs, feature_size)
        c: (bs, class_size)
        '''
        inputs = torch.cat([x, c], 1) # (bs, feature_size+class_size)
        h1 = self.elu(self.fc1(inputs))
        z_mu = self.fc21(h1)
        z_var = self.fc22(h1)
        return z_mu, z_var

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5*logvar)
        eps = torch.randn_like(std)
        return mu + eps*std

    def decode(self, z, c): # P(x|z, c)
        '''
        z: (bs, latent_size)
        c: (bs, class_size)
        '''
        inputs = torch.cat([z, c], 1) # (bs, latent_size+class_size)
        h3 = self.elu(self.fc3(inputs))
        return self.sigmoid(self.fc4(h3))

    def forward(self, x, c):
        mu, logvar = self.encode(x.view(x.shape[0], -1), c)
        z = self.reparameterize(mu, logvar)
        return self.decode(z, c), mu, logvar


# Reconstruction + KL divergence losses summed over all elements and batch
def loss_function(recon_x, x, mu, logvar):
    BCE = F.binary_cross_entropy(recon_x, x.view(-1, 784), reduction='sum')
    # see Appendix B from VAE paper:
    # Kingma and Welling. Auto-Encoding Variational Bayes. ICLR, 2014
    # https://arxiv.org/abs/1312.6114
    # 0.5 * sum(1 + log(sigma^2) - mu^2 - sigma^2)
    KLD = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    return BCE + KLD


def train(epoch,model,optimizer,train_loader,args):
    model.train()
    train_loss = 0
    for batch_idx, (data, labels) in enumerate(train_loader):
        data, labels = data.cuda(), labels.cuda()
        labels = one_hot(labels, args.num_class)
        recon_batch, mu, logvar = model(data, labels)
        optimizer.zero_grad()
        loss = loss_function(recon_batch, data, mu, logvar)
        loss.backward()
        train_loss += loss.detach().cpu().numpy()
        optimizer.step()
        if batch_idx % 20 == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch, batch_idx * len(data), len(train_loader.dataset),
                100. * batch_idx / len(train_loader),
                loss.item() / len(data)))

    print('====> Epoch: {} Average loss: {:.4f}'.format(
          epoch, train_loss / len(train_loader.dataset)))


def test(epoch,model,test_loader,args=None):
    model.eval()
    test_loss = 0
    with torch.no_grad():
        for i, (data, labels) in enumerate(test_loader):
            data, labels = data.cuda(), labels.cuda()
            labels = one_hot(labels, 10)
            recon_batch, mu, logvar = model(data, labels)
            test_loss += loss_function(recon_batch, data, mu, logvar).detach().cpu().numpy()
            if i == 0:
                n = min(data.size(0), 5)
                comparison = torch.cat([data[:n],
                                      recon_batch.view(-1, args.img_c, args.img_h, args.img_w)[:n]])
                save_image(comparison.cpu(),
                         f'{args.output_dir}/{args.model_name}/reconstruction_{epoch:02}.png', nrow=n)

    test_loss /= len(test_loader.dataset)
    print('====> Test set loss: {:.4f}'.format(test_loss))


            
def main():

    args = parse_args()

    # building dataset laoder
    train_loader = torch.utils.data.DataLoader(
        datasets.MNIST('/home/comp/chongyin/DataSets', train=True, download=True,
                   transform=transforms.ToTensor()),
        batch_size=args.batch_size, shuffle=True)
    
    test_loader = torch.utils.data.DataLoader(
        datasets.MNIST('/home/comp/chongyin/DataSets', train=False, transform=transforms.ToTensor()),
        batch_size=args.batch_size, shuffle=False)
    
    # create a cVAE model
    model = cVAE(args.img_h*args.img_w*args.img_c, args.latent_dim, args.num_class).cuda()
    optimizer = optim.Adam(model.parameters(), lr=args.lr)

    if not os.path.exists(os.path.join(args.output_dir,args.model_name)):
        os.makedirs(os.path.join(args.output_dir,args.model_name))

    for epoch in range(1, args.epochs + 1):
        train(epoch,model,optimizer,train_loader,args)
        test(epoch,model,test_loader,args)
        with torch.no_grad():
            c = torch.eye(args.num_class, args.num_class).cuda()
            sample = torch.randn(args.num_class, args.latent_dim).cuda()
            sample = model.decode(sample, c).cpu()
            save_image(sample.view(args.num_class, args.img_c, args.img_h, args.img_w),
                       f'{args.output_dir}/{args.model_name}/sample_{epoch:02}.png',) 


if __name__ == '__main__':
    main()
