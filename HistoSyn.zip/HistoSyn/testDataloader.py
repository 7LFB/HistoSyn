import argparse
import os
import pprint
import shutil
import sys

import logging
import time
import timeit
from pathlib import Path
import glob
import pandas as pd
import importlib

import re

import numpy as np
import json

import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
import torch.optim
from tensorboardX import SummaryWriter
import warnings
warnings.filterwarnings("ignore")


from torch.optim.lr_scheduler import MultiStepLR, LambdaLR, CosineAnnealingLR, StepLR

from core.function import train, validate, test
from utils.params import *
from utils.util import *
from utils.spatial_statistics import *
from dataset.myDataset import myTileDataset

from torchsampler import ImbalancedDatasetSampler

from pdb import set_trace as st

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
# 设置随机数种子

def main():
    args = parse_args()

    if args.data_version==0:
        if args.data_dir is None:
            args.data_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/clean_structures/'
        if args.file_list_folder is None:
            args.file_list_folder='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/CVFold/'
        if args.syn_data_dir is None:
            args.syn_data_dir='/home/comp/chongyin/DataSets/Liver-NASH/MICCAI21-Box-22/SyntheticSamples/stable-diffusion-v1-5/'
        if args.syn_file_list_folder is None:
            args.syn_file_list_folder=os.path.join(args.syn_data_dir,'CVFold')
        
    elif args.data_version==1:
        pass
    elif args.data_version==2:
        if args.data_dir is None:
            args.data_dir='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/'
        if args.file_list_folder is None:
            args.file_list_folder='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/CVFold/'
        if args.syn_data_dir is None:
            args.syn_data_dir='/home/comp/chongyin/DataSets/NAFLD_NORMAL_ANOMALY_HE_MOUSE_LIVER/SyntheticSamples/stable-diffusion-v1-5/'
        if args.syn_file_list_folder is None:
            args.syn_file_list_folder=os.path.join(args.syn_data_dir,'CVFold')
        
    elif args.data_version==3:
        pass


    setup_seed(args.seed)

    # using real or synthetic images, or mixed together for model training
    # pre-determine the ratio=synthetic/real 
    # real_syn_mode= 0 real data only, 1 syn data only, 2 mixed together
    if args.real_syn_mode==0:
        _x_train = [os.path.join(args.file_list_folder, 'train_fold_'+str(args.fold)+'.txt')]
        x_train = readlines_from_txt(_x_train)
    elif args.real_syn_mode==1:
        _x_train = [os.path.join(args.syn_file_list_folder, 'train_fold_'+str(args.fold)+'.txt')]
        x_train = readlines_from_txt(_x_train)
    elif args.real_syn_mode==2:
        _x_train_real = [os.path.join(args.file_list_folder, 'train_fold_'+str(args.fold)+'.txt')]
        _x_train_syn = [os.path.join(args.syn_file_list_folder, 'train_fold_'+str(args.fold)+'.txt')]
        x_train_real =readlines_from_txt(_x_train_real)
        x_train_syn =readlines_from_txt(_x_train_syn)
        if args.real_ratio<1.0: x_train_real=balance_sampler(x_train_real,args.real_ratio)
        x_train_syn = balance_sampler(x_train_syn,args.real_ratio*args.syn_to_real_ratio)
        x_train = x_train_real + x_train_syn
    
    # always val and test on real images
    _x_val = [os.path.join(args.file_list_folder, 'val_fold_'+str(args.fold)+'.txt')]
    _x_test = [os.path.join(args.file_list_folder, 'test_fold_'+str(args.fold)+'.txt')]
    x_val =readlines_from_txt(_x_val)
    x_test =readlines_from_txt(_x_test)

    x_test_tileNames=[x.split(' ')[0] for x in x_test]
    
    train_dataset=myTileDataset(x_train,args.data_dir,synDataDir=args.syn_data_dir,h=args.img_h,w=args.img_w,is_training=True,augment=args.augment,auto_augment=args.auto_augment,args=args)
    # validate and test on real dataset
    val_dataset=myTileDataset(x_val,args.data_dir,synDataDir=None,h=args.img_h,w=args.img_w,args=args)
    test_dataset=myTileDataset(x_test,args.data_dir,synDataDir=None,h=args.img_h,w=args.img_w,args=args)

    
    
    train_dataset.test(1)


if __name__ == '__main__':
    main()
